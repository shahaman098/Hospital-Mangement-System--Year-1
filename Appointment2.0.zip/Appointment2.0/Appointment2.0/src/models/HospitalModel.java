package models;

public class HospitalModel {
	private int providerId;
	private String hospitalName;
	private String address;
	private String city;
	private String state;
	private String zipCode;
	private String coutnry;
	private long phNumber;
	private String type;
	private String ownership;
	private String hasEmergencyService;
	private double rating;
	
	public int getProviderId() {
		return providerId;
	}
	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCoutnry() {
		return coutnry;
	}
	public void setCoutnry(String coutnry) {
		this.coutnry = coutnry;
	}
	public long getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(long phNumber) {
		this.phNumber = phNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOwnership() {
		return ownership;
	}
	public void setOwnership(String ownership) {
		this.ownership = ownership;
	}
	public String getHasEmergencyService() {
		return hasEmergencyService;
	}
	public void setHasEmergencyService(String hasEmergencyService) {
		this.hasEmergencyService = hasEmergencyService;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	
}
