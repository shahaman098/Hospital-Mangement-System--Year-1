package models;

import java.util.Date;

public class UserModel {
	private int id;
	private String firstName;
	private String lastName;
	private String email;
	private long phNumber;
	private String medicalConditions;
	private Date dob;
	private String gender;
	private String password;
	private String kinFirstName;
	private String kinLastName;
	private String kinEmail;
	private long kinPhNumber;
	private Date kinDob;
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getKinFirstName() {
		return kinFirstName;
	}
	public void setKinFirstName(String kinFirstName) {
		this.kinFirstName = kinFirstName;
	}
	public String getKinLastName() {
		return kinLastName;
	}
	public void setKinLastName(String kinLastName) {
		this.kinLastName = kinLastName;
	}
	public String getKinEmail() {
		return kinEmail;
	}
	public void setKinEmail(String kinEmail) {
		this.kinEmail = kinEmail;
	}
	public long getKinPhNumber() {
		return kinPhNumber;
	}
	public void setKinPhNumber(long kinPhNumber) {
		this.kinPhNumber = kinPhNumber;
	}
	public Date getKinDob() {
		return kinDob;
	}
	public void setKinDob(Date kinDob) {
		this.kinDob = kinDob;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(long phNumber) {
		this.phNumber = phNumber;
	}
	public String getMedicalConditions() {
		return medicalConditions;
	}
	public void setMedicalConditions(String medicalConditions) {
		this.medicalConditions = medicalConditions;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
