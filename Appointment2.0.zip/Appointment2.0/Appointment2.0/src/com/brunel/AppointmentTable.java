package com.brunel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class AppointmentTable extends BaseWindow {

	private JFrame frame;
	private JTable table;
	
	public AppointmentTable() {
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Appointment List");
		lblNewLabel.setForeground(new Color(51, 51, 51));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setBounds(36, 70, 405, 61);
		panel.add(lblNewLabel);
		
		String[][] data = {
                {"", "18:15 - 19:00", "Dianne Russell", "Upper Abdomen pain", "Hillingdon", "4517 Washington Ave. Manchester, Kentucky 39495", "Scheduled", ""}
            };

		String[] columnNames = {"","TIME", "PATIENT", "DIAGNOSIS", "HOSPITAL", "LOCATION", "STATUS", ""};
		DefaultTableModel model = new DefaultTableModel(data, columnNames);
		table = new JTable(model);
		
		DefaultTableCellRenderer noBorderRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(new Color(249, 249, 251));
                if (c instanceof JComponent) {
                    ((JComponent) c).setBorder(null);
                }
                return c;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(noBorderRenderer);
        }
        
		table.setBounds(30, 135, 1036, 61);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setLocation(36, 157);
		scrollPane.getViewport().setBackground(Color.WHITE);
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setSize(1352, 319);
		
		panel.add(scrollPane);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
