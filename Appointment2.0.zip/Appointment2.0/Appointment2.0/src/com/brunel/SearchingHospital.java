package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brunel.components.AppointmentItemPanel;

import models.AppointmentModel;


public class SearchingHospital extends BaseWindow{

	JFrame frame;
	AppointmentModel appointment;
	
	public SearchingHospital(AppointmentModel appointment) {
		super();
		this.setAppointment(appointment);
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		panel.setLayout(null);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("Hospitals");
		panel_1.setBounds(458, 103, panel_1.getWidth(), panel_1.getHeight());
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Searching Available Dates");
		lblNewLabel.setBounds(524, 296, 490, 55);
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(getClass().getResource("/images/loading.png")));
		lblNewLabel_1.setBounds(523, 377, 467, 511);
		panel.add(lblNewLabel_1);
		
		Timer timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                AppointmentModel appointment = getAppointment();
                new AppointmentListWindow(appointment).getFrame().setVisible(true);
            }
        });
		
        timer.setRepeats(false);
        timer.start();
		
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
