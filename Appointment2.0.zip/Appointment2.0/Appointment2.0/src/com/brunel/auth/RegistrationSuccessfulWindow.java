package com.brunel.auth;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.BaseWindow;

public class RegistrationSuccessfulWindow extends BaseWindow {

	JFrame frame;

	public RegistrationSuccessfulWindow() {
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		
		panel.setSize(1440, 900);
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registration Confirmation");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 46));
		lblNewLabel.setBounds(441, 80, 595, 73);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setVgap(50);
		panel_1.setBackground(new Color(255, 184, 0));
		panel_1.setBounds(150, 184, 1149, 684);
		panel.add(panel_1);
		
		String msg = "<html><body style='text-align:center;'><p>You have been officially</p><p>registered</p></body></html>";
		JLabel lblNewLabel_1 = new JLabel(msg);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(getClass().getResource("/images/checkmark.png")));
		panel_1.add(lblNewLabel_2);
		
		String msg1 = "<html><body style='text-align:center;'><p>Now you can login with</p><p>your username and password</p></body></html>";
		JLabel lblNewLabel_1_1 = new JLabel(msg1);
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1_1);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
