package com.brunel.auth;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brunel.BaseWindow;
import com.brunel.components.DatePanel;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

import models.UserModel;

public class KinWindow extends BaseWindow {

	JFrame frame;
	private UserModel user;

	public KinWindow(UserModel user) {
		super();
		this.user = user;
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		frame.setName("Kin Window");
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 922);

		frame.getContentPane().add(panel);

		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Kin’s information");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setBounds(82, 58, 698, 114);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Please Sign Up To Continue");
		lblNewLabel_1.setForeground(new Color(158, 158, 158));
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_1.setBounds(82, 172, 634, 66);
		panel.add(lblNewLabel_1);

		TextInput kinFirstName = new TextInput(8, "Kin's First Name");
		kinFirstName.setBounds(82, 394, 534, 54);
		panel.add(kinFirstName);
		kinFirstName.setColumns(10);

		TextInput kinLastName = new TextInput(8, "Kin's Last Name");
		kinLastName.setColumns(10);
		kinLastName.setBounds(717, 394, 534, 54);
		panel.add(kinLastName);

		TextInput kinEmail = new TextInput(8, "Kin's Email");
		kinEmail.setColumns(10);
		kinEmail.setBounds(82, 507, 534, 54);
		panel.add(kinEmail);

		TextInput kinPhNumber = new TextInput(8, "Kin's Mobile Number");
		kinPhNumber.setColumns(10);
		kinPhNumber.setBounds(717, 507, 534, 54);
		panel.add(kinPhNumber);

		DatePanel calendarPanel = new DatePanel(frame, "Date of Birth");
		calendarPanel.setBounds(328, 608, 534, 60);
		panel.add(calendarPanel);

		RoundedButton registerBtn = new RoundedButton("Register/Sign Up");
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String kinFname = kinFirstName.getText();
				String kinLname = kinLastName.getText();
				String email = kinEmail.getText();

				Long kinMobile = Long.parseLong(kinPhNumber.getText());

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date dob = null;

				try {
					dob = sdf.parse(calendarPanel.getDate());
				} catch (ParseException e1) {
					dob = null;
				}

				user.setKinFirstName(kinFname);
				user.setKinLastName(kinLname);
				user.setKinEmail(email);
				user.setKinDob(dob);
				user.setKinPhNumber(kinMobile);

				ArrayList<UserModel> users = getAllUsers();
				Boolean isSaveSuccess = null;

				if (users.isEmpty()) {
					user.setId(1);
					isSaveSuccess = saveUser(user);
				} else {
					UserModel lastUser = users.getLast();
					user.setId(lastUser.getId() + 1);
					isSaveSuccess = saveUser(user);
				}

				if (isSaveSuccess) {
					frame.dispose();
					new RegistrationSuccessfulWindow().getFrame().setVisible(true);
				} else {
					JOptionPane.showMessageDialog(frame, "Error Registering the User", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
		});

		registerBtn.setFont(new Font("Dialog", Font.BOLD, 29));
		registerBtn.setForeground(new Color(255, 255, 255));
		registerBtn.setBackground(new Color(83, 101, 119));
		registerBtn.setBounds(474, 738, 308, 57);
		panel.add(registerBtn);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
