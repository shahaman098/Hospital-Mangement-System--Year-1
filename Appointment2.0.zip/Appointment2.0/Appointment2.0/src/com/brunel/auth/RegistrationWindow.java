package com.brunel.auth;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brunel.BaseWindow;
import com.brunel.components.DatePanel;
import com.brunel.components.PasswordField;
import com.brunel.components.RoundedButton;
import com.brunel.components.RoundedComboBoxUI;
import com.brunel.components.TextInput;

import models.UserModel;

public class RegistrationWindow extends BaseWindow {

	JFrame frame;

	public RegistrationWindow() {
		super();
		frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		frame.setName("Registration Frame");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 69, 1440, 922);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Patient's information");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setBounds(82, 58, 794, 99);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_8 = new JLabel("Please Sign Up To Continue");
		lblNewLabel_8.setForeground(new Color(192, 191, 188));
		lblNewLabel_8.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_8.setBounds(82, 169, 488, 50);
		panel.add(lblNewLabel_8);

		String paragraph = "We are excited to assist you with your needs. Please follow the </br>simple steps below to sign up for an appointment";
		JLabel lblNewLabel_9 = new JLabel();
		lblNewLabel_9.setForeground(new Color(158, 158, 158));
		lblNewLabel_9.setText("<html><p>" + paragraph + "</p></html>");
		lblNewLabel_9.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_9.setBounds(82, 228, 607, 50);
		panel.add(lblNewLabel_9);

		TextInput fName = new TextInput(8, "First Name");
		fName.setLocation(82, 314);
		fName.setSize(534, 60);
		panel.add(fName);

		TextInput lName = new TextInput(8, "Last Name");
		lName.setBounds(758, 314, 534, 60);
		panel.add(lName);

		TextInput email = new TextInput(8, "Email");
		email.setBounds(82, 404, 534, 60);
		panel.add(email);

		TextInput ph_number = new TextInput(8, "Mobile Number");
		ph_number.setBounds(758, 404, 534, 60);
		panel.add(ph_number);

		TextInput medical_problem = new TextInput(8, "Any Medical Problem");
		medical_problem.setBounds(82, 496, 534, 60);
		panel.add(medical_problem);

		DatePanel calendarPanel = new DatePanel(frame, "Date of Birth");
		calendarPanel.setBounds(758, 496, 534, 60);
		panel.add(calendarPanel);

		String genders[] = { "Male", "Female", "Others" };

		JComboBox gender = new JComboBox(genders);
		gender.setForeground(new Color(158, 158, 158));
		gender.setFont(new Font("Arial", Font.PLAIN, 26));
		gender.setBackground(new Color(255, 255, 255));
		gender.setBounds(83, 600, 342, 60);
		gender.setUI(new RoundedComboBoxUI());
		panel.add(gender);

		PasswordField password = new PasswordField(8, "Password");
		password.setBounds(526, 600, 342, 60);
		panel.add(password);

		PasswordField c_password = new PasswordField(8, "Confirm Password");
		c_password.setBounds(950, 600, 342, 60);
		panel.add(c_password);

		RoundedButton nextBtn = new RoundedButton("Sign Up");
		nextBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> errors = new ArrayList<>();

				UserModel user = new UserModel();

				String firstName = fName.getText();
				String lastName = lName.getText();
				String userEmail = email.getText();
				long phNumber = 0;
				try {
					phNumber = Long.parseLong(ph_number.getText());
				} catch (Exception e2) {
					phNumber = 0;
				}

				String medicalProblems = medical_problem.getText();
				String userGender = gender.getSelectedItem().toString();

				char[] pwdChars = password.getPassword();
				String pwd = new String(pwdChars);

				char[] cpwdChars = c_password.getPassword();
				String cPwd = new String(cpwdChars);

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date dob = null;

				try {
					dob = sdf.parse(calendarPanel.getDate());
				} catch (ParseException e1) {
					dob = null;
				}

				if (firstName.isEmpty() || lastName.isEmpty() || userEmail.isEmpty() || phNumber == 0
						|| medicalProblems.isEmpty() || userGender.isEmpty() || pwd.isEmpty() || cPwd.isEmpty()
						|| dob == null) {
					errors.add("All fields need to filled before moving on.");
				} else if (!pwd.equals(cPwd)) {
					errors.add("Password and Confirm Passowrd must be same.");
				}

				if (!errors.isEmpty()) {
					JOptionPane.showMessageDialog(frame, errors.getFirst(), "Validation Error",
							JOptionPane.ERROR_MESSAGE);
					errors.removeFirst();
					return;
				} else {
					user.setFirstName(firstName);
					user.setLastName(lastName);
					user.setEmail(userEmail);
					user.setPhNumber(phNumber);
					user.setMedicalConditions(medicalProblems);
					user.setGender(userGender);
					user.setPassword(pwd);
					user.setDob(dob);

					ArrayList<UserModel> users = getAllUsers();
					Boolean isExist = false;

					for (UserModel u : users) {
						if (u.getEmail().matches(user.getEmail())) {
							isExist = true;
							break;
						}
					}

					if (isExist) {
						JOptionPane.showMessageDialog(frame, "The user with this email already exists", "Error",
								JOptionPane.ERROR_MESSAGE);
						return;
					}else {
						frame.dispose();
						new KinWindow(user).getFrame().setVisible(true);
					}
				}
			}
		});

		nextBtn.setText("Next");
		nextBtn.setForeground(Color.WHITE);
		nextBtn.setFont(new Font("Dialog", Font.BOLD, 29));
		nextBtn.setBackground(new Color(83, 101, 119));
		nextBtn.setBounds(538, 739, 308, 56);
		panel.add(nextBtn);
	}
}
