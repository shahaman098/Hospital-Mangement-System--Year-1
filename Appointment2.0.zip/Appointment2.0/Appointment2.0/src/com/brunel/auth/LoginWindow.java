package com.brunel.auth;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brunel.AppointmentWindow;
import com.brunel.BaseWindow;
import com.brunel.components.PasswordField;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

import models.UserModel;

public class LoginWindow extends BaseWindow {
	private JFrame home;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginWindow window = new LoginWindow();
					window.home.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public LoginWindow() {
		super();
		home = super.getFrame();
		getAllAppointments();
		initialize();
	}

	private void initialize() {
		JPanel main = new JPanel();
		main.setBackground(new Color(255, 255, 255));
		main.setBounds(22, 80, 1440, 911);
		home.getContentPane().add(main);
		main.setLayout(null);
		
		JPanel left = new JPanel();
		left.setToolTipText("");
		left.setBackground(new Color(255, 255, 255));
		left.setBounds(12, 5, 870, 590);
		main.add(left);
		left.setLayout(null);
		
		JLabel h1 = new JLabel("Sign In");
		h1.setForeground(new Color(13, 41, 74));
		h1.setBounds(10, 63, 249, 99);
		h1.setFont(new Font("Dialog", Font.BOLD, 72));
		left.add(h1);
		
		JLabel lblNewLabel = new JLabel("Please Login To Continue");
		lblNewLabel.setForeground(new Color(83, 101, 119));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 32));
		lblNewLabel.setBounds(10, 203, 500, 42);
		left.add(lblNewLabel);
		
		JLabel lblNewLabel_8 = new JLabel("Please sign in to access your account and manage your appointments.");
		lblNewLabel_8.setFont(new Font("Dialog", Font.BOLD, 12));
		lblNewLabel_8.setBounds(10, 256, 461, 17);
		left.add(lblNewLabel_8);
		
		TextInput emailField = new TextInput(8, "Email");
		emailField.setBounds(10, 324, 420, 63);
		left.add(emailField);
		emailField.setColumns(10);
		
		PasswordField passwordField = new PasswordField(8, "Password");
		passwordField.setColumns(10);
		passwordField.setBounds(10, 439, 420, 63);
		left.add(passwordField);
		
		JPanel right = new JPanel();
		right.setBackground(new Color(255, 255, 255));
		right.setBounds(894, 5, 501, 590);
		main.add(right);
		
		ImageIcon heroImage = new ImageIcon(getClass().getResource("/images/hero.jpeg"));
		
		Image temp = heroImage.getImage();
		Image newHero = temp.getScaledInstance(right.getWidth(), right.getHeight(), java.awt.Image.SCALE_SMOOTH);
		heroImage = new ImageIcon(newHero);
		
		JLabel hero = new JLabel(heroImage);
		right.add(hero);
		
		JPanel buttons = new JPanel();
		buttons.setBorder(null);
		buttons.setBackground(new Color(255, 255, 255));
		buttons.setBounds(12, 607, 1383, 304);
		main.add(buttons);
		buttons.setLayout(null);
		
		JLabel lblNewLabel_9 = new JLabel("Haven't Registerted Yet!");
		lblNewLabel_9.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_9.setBounds(22, 88, 244, 17);
		buttons.add(lblNewLabel_9);
        
		RoundedButton signUp = new RoundedButton("Sign Up");
		
		signUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				home.dispose();
				new RegistrationWindow().frame.setVisible(true);
			}
		});
		signUp.setBackground(new Color(83, 101, 119));
		signUp.setForeground(new Color(255, 255, 255));
		signUp.setFont(new Font("Dialog", Font.BOLD, 29));
		signUp.setBounds(12, 129, 274, 67);
		buttons.add(signUp);
		
		RoundedButton signIn = new RoundedButton("Sign Up");
		signIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userEmail = emailField.getText();
				char[] pwd = passwordField.getPassword();
				String userPassword = new String(pwd);
				
				ArrayList<UserModel> users = getAllUsers();
				Boolean isUserExist = false;
				
				UserModel user = null;
				for (UserModel u : users) {
					if (u.getEmail().equals(userEmail)) {
						setUser(u);
						user = getUser();
						isUserExist = true;
						break;
					}
				}
				
				if (!isUserExist) {
					JOptionPane.showMessageDialog(home, "User Doesn't Exist, Register First", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}else {
					if (user.getPassword().equals(userPassword)) {
						home.dispose();
						new AppointmentWindow(user).getFrame().setVisible(true);
					}else {
						JOptionPane.showMessageDialog(home, "Incorrect Password, Please Try Again", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
			}
		});
		
		signIn.setText("Sign In");
		signIn.setForeground(Color.WHITE);
		signIn.setFont(new Font("Dialog", Font.BOLD, 29));
		signIn.setBackground(new Color(83, 101, 119));
		signIn.setBounds(705, 129, 274, 67);
		buttons.add(signIn);
	}
}
