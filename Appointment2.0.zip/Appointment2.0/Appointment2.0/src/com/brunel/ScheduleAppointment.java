package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.AppointmentItemPanel;

import models.UserModel;

public class ScheduleAppointment extends BaseWindow{

	JFrame frame;
	
	public ScheduleAppointment(UserModel user) {
		super();
		this.frame = super.getFrame();
		this.setUser(user);
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		
		panel.setSize(1440, 900);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Schedule an Appointment");
		lblNewLabel.setBounds(273, 115, 932, 99);
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		panel.add(lblNewLabel);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("First Appointment");
		panel_1.setBounds(55, 485, panel_1.getWidth(), panel_1.getHeight());
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				UserModel user = getUser();
				new AppointmentBooking(user).getFrame().setVisible(true);
			}
		});
		panel.add(panel_1);
		
		AppointmentItemPanel panel_1_1 = new AppointmentItemPanel("Second Appointment");
		panel_1_1.setBounds(761, 485, 608, 140);
		panel_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				new SecondAppointmentWindow().getFrame().setVisible(true);
			}
		});
		panel.add(panel_1_1);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
