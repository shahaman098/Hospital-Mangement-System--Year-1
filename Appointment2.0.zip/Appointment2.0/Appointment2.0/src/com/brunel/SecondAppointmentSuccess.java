package com.brunel;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SecondAppointmentSuccess extends BaseWindow{

	private JFrame frame;
	public SecondAppointmentSuccess() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		panel.setLayout(null);
		
		JLabel lblConfirmation = new JLabel("Confirmation");
		lblConfirmation.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 46));
		lblConfirmation.setBounds(636, 105, 297, 73);
		panel.add(lblConfirmation);
		
		JPanel panel_1 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setVgap(25);
		panel_1.setBackground(new Color(255, 184, 0));
		panel_1.setBounds(171, 190, 1149, 800);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body style='text-align:center;'><p>Your Follow-up booking is</p><p>confirmed</p></body></html>");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(getClass().getResource("/images/checkmark.png")));
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("<html><body style='text-align:center;'><p>Your Appointment ID is </p><p>:B230838 as same as previous.</p><p>appointment dates will be<p>emailed you soon.</p></p></body></html>");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1_1);
		
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

}
