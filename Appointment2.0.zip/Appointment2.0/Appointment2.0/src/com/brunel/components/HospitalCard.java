package com.brunel.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.IOException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class HospitalCard extends RoundedPanel {
	
    public HospitalCard(URL imagePath, String title, String description, String address, double rating) throws IOException { 
		this.setBackground(new Color(255, 255, 255));
		this.setPreferredSize(new Dimension(357, 246));
		this.setLayout(null);
		
		ImageIcon hospital_icon = RoundedImageIcon.getRoundedImageIcon(imagePath, 100);
		JLabel card_icon = new JLabel(hospital_icon);
		card_icon.setBounds(23, 12, 95, 95);
		this.add(card_icon);
		
		ImageIcon circle = new ImageIcon(getClass().getResource("/images/circle_small.png"));
		JLabel lblNewLabel_2 = new JLabel(circle);
		lblNewLabel_2.setBounds(115, 12, 19, 17);
		this.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel(title);
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 24));
		lblNewLabel_3.setForeground(new Color(0, 114, 140));
		lblNewLabel_3.setBounds(23, 122, 273, 33);
		this.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel(description);
		lblNewLabel_4.setFont(new Font("Dialog", Font.PLAIN, 18));
		lblNewLabel_4.setForeground(new Color(255, 184, 0));
		lblNewLabel_4.setBounds(23, 166, 241, 17);
		this.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel(address);
		lblNewLabel_5.setForeground(new Color(255, 184, 0));
		lblNewLabel_5.setFont(new Font("Dialog", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(23, 195, 322, 17);
		this.add(lblNewLabel_5);
		
		ImageIcon starImage = new ImageIcon(getClass().getResource("/images/star.png"));
		JLabel lblNewLabel_6 = new JLabel(starImage);
		lblNewLabel_6.setBounds(326, 12, 19, 17);
		this.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel(rating + "");
		lblNewLabel_7.setForeground(new Color(0, 114, 140));
		lblNewLabel_7.setBounds(306, 12, 19, 17);
		this.add(lblNewLabel_7);
    }
}
