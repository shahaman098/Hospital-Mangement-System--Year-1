package com.brunel.components;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JButton;

public class RoundedButton extends JButton {

	private static final long serialVersionUID = 1L;

	public RoundedButton(String text) {
		super(text);
		setContentAreaFilled(false);
		setFocusPainted(false);
		setBorderPainted(false);
	}

	@Override
	protected void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		// Paint background
		g2.setColor(getBackground());
		g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));

		// Paint text
		FontMetrics fm = g2.getFontMetrics();
		Rectangle r = getBounds();
		int x = (r.width - fm.stringWidth(getText())) / 2;
		int y = (r.height - fm.getHeight()) / 2 + fm.getAscent();
		g2.setColor(getForeground());
		g2.drawString(getText(), x, y);

		g2.dispose();
		super.paintComponent(g);
	}

	@Override
	protected void paintBorder(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setColor(getForeground());
		g2.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
		g2.dispose();
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();
		d.width = d.height = Math.max(d.width, d.height);
		return d;
	}
}
