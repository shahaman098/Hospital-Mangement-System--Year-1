package com.brunel.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class SearchBox extends JPanel{
	public SearchBox() {
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setBackground(getBackground());
		
		RoundedPanel searchPanel = new RoundedPanel();
		searchPanel.setForeground(new Color(158, 158, 158));
		searchPanel.setBackground(new Color(255, 255, 255));
		searchPanel.setLayout(new BorderLayout());
		searchPanel.setBorder(new EmptyBorder(5, 20, 5, 20));
		
		JTextField searchField = new JTextField(15);
		searchField.setForeground(new Color(158, 158, 158));
		searchField.setText("Search");
		searchField.setFont(new Font("Dialog", Font.PLAIN, 26));
		searchField.setBackground(new Color(255, 255, 255));
        searchField.setEditable(false); 
        searchField.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));
        
        JButton searchButton = new JButton();
        searchButton.setBackground(new Color(255, 255, 255));
        searchButton.setBorder(BorderFactory.createEmptyBorder());
        ImageIcon searchIcon = new ImageIcon(getClass().getResource("/images/search.png"));
        searchButton.setIcon(searchIcon);
        
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);
        
		searchPanel.setBounds(758, 496, 534, 60);
		
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
		this.add(searchPanel);

        // Add ActionListener to the button
        searchButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	}
}
