package com.brunel.components;
import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AppointmentItemPanel extends JPanel{
	public AppointmentItemPanel(String text) {
		this.setSize(608, 140);
		this.setForeground(new Color(191, 63, 63));
		this.setBackground(new Color(255, 184, 0));
		
		this.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel(text);
		lblNewLabel_1.setForeground(new Color(119, 118, 123));
		lblNewLabel_1.setBounds(13, 21, 650, 99);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_1.setIcon(new ImageIcon(getClass().getResource("/images/female_icon.png")));
		this.add(lblNewLabel_1);
	}
}
