package com.brunel.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.JTextField;

public class TextInput extends JTextField {
	private Shape shape;
	private String placeholder;

	public TextInput(int size, String placeholder) {
			super(size);
			this.placeholder = placeholder;
			this.setBorder(BorderFactory.createEmptyBorder(0, 49, 0, 50));
			this.setForeground(new Color(158, 158, 158));
			this.setFont(new Font("Dialog", Font.PLAIN, 26));
			setOpaque(false);
		}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
        if (getText().isEmpty() && !isFocusOwner()) {
        	Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(158, 158, 158));
            g2.drawString(placeholder, getInsets().left+2, g2.getFontMetrics().getMaxAscent() + 10);
            g2.dispose();
        }
	}

	protected void paintBorder(Graphics g) {
		g.setColor(getForeground());
		g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
	}

	public boolean contains(int x, int y) {
		if (shape == null || !shape.getBounds().equals(getBounds())) {
			shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
		}
		return shape.contains(x, y);
	}
}
