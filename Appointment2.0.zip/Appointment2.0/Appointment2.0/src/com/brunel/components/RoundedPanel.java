package com.brunel.components;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;

public class RoundedPanel extends JPanel {
	private static final int ARC_WIDTH = 15;
    private static final int ARC_HEIGHT = 15;
    private static final int BORDER_THICKNESS = 1;

    public RoundedPanel() {
        setOpaque(false); // Set the panel to be non-opaque
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Set the color for the panel background
        g2d.setColor(getBackground());
        g2d.fillRoundRect(BORDER_THICKNESS, BORDER_THICKNESS,
                width - 2 * BORDER_THICKNESS, height - 2 * BORDER_THICKNESS, ARC_WIDTH, ARC_HEIGHT);

        // Set the color for the border
        g2d.setColor(getForeground());
        g2d.setStroke(new BasicStroke(BORDER_THICKNESS));
        g2d.drawRoundRect(BORDER_THICKNESS / 2, BORDER_THICKNESS / 2,
                width - BORDER_THICKNESS, height - BORDER_THICKNESS, ARC_WIDTH, ARC_HEIGHT);
    }
}
