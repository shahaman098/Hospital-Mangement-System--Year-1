package com.brunel.components;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.plaf.basic.BasicComboBoxUI;

public class RoundedComboBoxUI extends BasicComboBoxUI{
		protected void installDefaults() {
	        super.installDefaults();
	        comboBox.setOpaque(false);
	    }

	    @Override
	    public void paint(Graphics g, JComponent c) {
	    	Graphics2D g2 = (Graphics2D) g;
	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	        
	        g2.setColor(c.getBackground());
	        g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 20, 20);

	        g2.setColor(new Color(158, 158, 158));
	        g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 20, 20);

	        super.paint(g2, c);

	    }

	    @Override
	    protected JButton createArrowButton() {
	        JButton button = new JButton("▼");
	        button.setContentAreaFilled(false);
	        button.setBorderPainted(false);
	        return button;
	    }

	    @Override
	    public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {

	    }

	    @Override
	    protected ListCellRenderer<Object> createRenderer() {
	    	return new CustomComboBoxRenderer();
	    }
	    
	    private static class CustomComboBoxRenderer extends DefaultListCellRenderer {
	        @Override
	        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
	            label.setOpaque(false);
	            label.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 50)); // Adding padding: top, left, bottom, right
	            return label;
	        }
	    }
}
