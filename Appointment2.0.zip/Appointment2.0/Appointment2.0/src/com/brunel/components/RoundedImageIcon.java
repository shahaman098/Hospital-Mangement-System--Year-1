package com.brunel.components;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class RoundedImageIcon {
	public static ImageIcon getRoundedImageIcon(URL imagePath, int size) throws IOException {
        // Load the image from the absolute file path
        BufferedImage originalImage = ImageIO.read(imagePath);
        
        // Crop the image to a square
        int diameter = Math.min(originalImage.getWidth(), originalImage.getHeight());
        BufferedImage croppedImage = originalImage.getSubimage(
                (originalImage.getWidth() - diameter) / 2,
                (originalImage.getHeight() - diameter) / 2,
                diameter,
                diameter);

        // Create a buffered image with transparency
        BufferedImage roundedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);

        // Draw the rounded image
        Graphics2D g2 = roundedImage.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new Ellipse2D.Double(0, 0, diameter, diameter));
        g2.drawImage(croppedImage, 0, 0, diameter, diameter, null);
        g2.dispose();

        return new ImageIcon(roundedImage);
	}
}
