package com.brunel.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JCalendar;

public class DatePanel extends RoundedPanel {
	public String date;
	
	public DatePanel(JFrame parent, String text) {
		this.setForeground(new Color(158, 158, 158));
		this.setBackground(new Color(255, 255, 255));
		this.setLayout(new BorderLayout());
		this.setBorder(new EmptyBorder(5, 20, 5, 20));

		JTextField dateField = new JTextField(15);
		dateField.setForeground(new Color(158, 158, 158));
		dateField.setText(text);
		dateField.setFont(new Font("Dialog", Font.PLAIN, 26));
		dateField.setBackground(new Color(255, 255, 255));
		dateField.setEditable(false);
		dateField.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));

		JButton calendarButton = new JButton();
		calendarButton.setBackground(new Color(255, 255, 255));
		calendarButton.setBorder(BorderFactory.createEmptyBorder());
		ImageIcon calendarIcon = new ImageIcon(getClass().getResource("/images/calendar.png"));
		calendarButton.setIcon(calendarIcon);

		JCalendar calendar = new JCalendar();
		JDialog calendarDialog = new JDialog(parent, "Select Date", true);
		calendarDialog.getContentPane().add(calendar);
		calendarDialog.pack();

		calendarButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				calendarDialog.setLocationRelativeTo(dateField);
				calendarDialog.setVisible(true);
			}
		});

		calendar.addPropertyChangeListener("calendar", evt -> {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			this.date = sdf.format(calendar.getDate());
			dateField.setText(this.date);
			calendarDialog.setVisible(false);
		});

		this.add(dateField, BorderLayout.CENTER);
		this.add(calendarButton, BorderLayout.EAST);
	}
	
	public String getDate() {
		return this.date;
	}
}
