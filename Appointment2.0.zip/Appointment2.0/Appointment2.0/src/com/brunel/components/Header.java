package com.brunel.components;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.AppointmentListWindow;
import com.brunel.FeedbackForm;

import models.AppointmentModel;

public class Header extends JPanel{
	public Header() {
		this.setBackground(new Color(255, 255, 255));
		this.setBounds(12, 0, 1440, 68);
		this.setLayout(null);
		
		ImageIcon imageIcon = new ImageIcon(getClass().getResource("/images/Logo.png"));
		Image image = imageIcon.getImage();
		Image newimg = image.getScaledInstance(300, 150,  java.awt.Image.SCALE_SMOOTH);
		imageIcon = new ImageIcon(newimg); 
		
		JLabel logo = new JLabel(imageIcon);
		logo.setBounds(0, 12, 261, 70);
		this.add(logo);
		
		JPanel nav_menu = new JPanel();
		FlowLayout fl_nav_menu = new FlowLayout(FlowLayout.CENTER);
		fl_nav_menu.setVgap(25);
		fl_nav_menu.setHgap(45);
		nav_menu.setLayout(fl_nav_menu);
		nav_menu.setBackground(new Color(255, 255, 255));
		nav_menu.setBounds(250, 0, 1170, 70);
		this.add(nav_menu);
		
		JLabel lblNewLabel_1 = new JLabel("Home");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 18));
		nav_menu.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Apointment");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 18));
		
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
//				new AppointmentListWindow().frame.setVisible(true);
			}
		});
		nav_menu.add(lblNewLabel_2);
		
		
		JLabel lblNewLabel_3 = new JLabel("Patient");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 18));
		nav_menu.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Doctor Review");
		lblNewLabel_4.setFont(new Font("Dialog", Font.BOLD, 18));
		nav_menu.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Restaurant");
		lblNewLabel_5.setFont(new Font("Dialog", Font.BOLD, 18));
		nav_menu.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Finances");
		lblNewLabel_6.setFont(new Font("Dialog", Font.BOLD, 18));
		nav_menu.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("About Us");
		lblNewLabel_7.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new FeedbackForm().getFrame().setVisible(true);
			}
		});
		nav_menu.add(lblNewLabel_7);
	}
	
}
