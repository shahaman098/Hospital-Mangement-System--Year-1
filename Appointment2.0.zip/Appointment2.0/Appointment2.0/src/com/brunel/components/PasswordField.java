package com.brunel.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.JPasswordField;

public class PasswordField extends JPasswordField {
	public static final Color placeholderColor = Color.gray;
	private String placeholder;
	private Shape shape;

	public PasswordField(int size, String placeholder) {
		super(size);
		this.placeholder = placeholder;
		this.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 50));
		this.setForeground(new Color(158, 158, 158));
		this.setFont(new Font("Dialog", Font.PLAIN, 26));
		setOpaque(false);
	}

	@Override
	protected void paintComponent(Graphics pG) {
		super.paintComponent(pG);

		if (getPassword().length == 0 && placeholder.length() > 0) {
			final Graphics2D g = (Graphics2D) pG.create();
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g.setColor(placeholderColor);
			int offset = 10;
			g.drawString(placeholder, getInsets().left, pG.getFontMetrics().getMaxAscent() + offset);
			g.dispose();
		}
	}

	@Override
	protected void paintBorder(Graphics g) {
		g.setColor(getForeground());
		g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
	}

	@Override
	public boolean contains(int x, int y) {
		if (shape == null || !shape.getBounds().equals(getBounds())) {
			shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
		}
		return shape.contains(x, y);
	}
}
