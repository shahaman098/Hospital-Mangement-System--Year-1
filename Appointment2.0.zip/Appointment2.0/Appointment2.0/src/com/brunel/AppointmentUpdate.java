package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brunel.components.AppointmentItemPanel;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

import models.AppointmentModel;
import models.UserModel;

public class AppointmentUpdate extends BaseWindow {

	private JFrame frame;

	public AppointmentUpdate(UserModel user) {
		super();
		setUser(user);
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("Update an Appointment");
		panel_1.setBounds(541, 186, 645, 140);
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Enter your Appointment ID");
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setBounds(258, 359, 992, 106);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Please Confirm To Update");
		lblNewLabel_2.setForeground(new Color(192, 191, 188));
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_2.setBounds(258, 477, 723, 50);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body><p>If you want to update the details regarding your appointment please</p><p>go ahead and provide your Appoinment ID and edit the personal details file.</p></body></html>");
		lblNewLabel_1.setForeground(new Color(192, 191, 188));
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1.setBounds(258, 539, 723, 97);
		panel.add(lblNewLabel_1);
		
		TextInput appointmentId = new TextInput(8, "Appointment ID");
		appointmentId.setColumns(10);
		appointmentId.setBounds(258, 671, 625, 63);
		panel.add(appointmentId);
		
		RoundedButton btnNewButton = new RoundedButton("Confirm");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = appointmentId.getText();
				UserModel user = getUser();
				AppointmentModel appointment = getAppointment(id);
				
				if (appointment == null) {
					JOptionPane.showMessageDialog(frame, "The appointment with this id doesn't exist.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}else if (appointment.getPatientId() != user.getId()) {
					JOptionPane.showMessageDialog(frame, "Sorry, you haven't booked an appointment with this id", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				new AppointmentUpdateDetails(appointment).getFrame().setVisible(true);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 29));
		btnNewButton.setBackground(new Color(83, 101, 119));
		btnNewButton.setBounds(717, 844, 308, 56);
		panel.add(btnNewButton);
		
		RoundedButton rndbtnBack = new RoundedButton("Confirm");
		rndbtnBack.setText("Back");
		rndbtnBack.setForeground(Color.WHITE);
		rndbtnBack.setFont(new Font("Dialog", Font.BOLD, 29));
		rndbtnBack.setBackground(new Color(83, 101, 119));
		rndbtnBack.setBounds(351, 844, 308, 56);
		panel.add(rndbtnBack);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
