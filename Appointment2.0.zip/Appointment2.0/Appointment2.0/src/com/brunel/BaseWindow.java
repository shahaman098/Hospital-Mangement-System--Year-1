package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.swing.JFrame;

import com.brunel.components.Header;

import models.AppointmentModel;
import models.UserModel;
import models.HospitalModel;

public class BaseWindow {

	private JFrame frame;
	private UserModel user;
	private AppointmentModel appointment;
	
	int screen_width = 1440;
	int screen_height = 1024;
	
	public BaseWindow() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Arial", Font.PLAIN, 12));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		
		frame.getContentPane().setLayout(null);
		
		Header header = new Header();
		frame.getContentPane().add(header);
		
		frame.setBounds(0, 0, screen_width, screen_height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
	}
	
	public JFrame getFrame() {
		return this.frame;
	}
	
	public UserModel getUser() {
		return this.user;
	}
	
	public void setUser(UserModel user) {
		this.user = user;
	}
	
	public AppointmentModel getAppointment() {
		return appointment;
	}

	public void setAppointment(AppointmentModel appointment) {
		this.appointment = appointment;
	}
	
	public static String getAllFields(Object obj) {
        Class<?> clazz = obj.getClass();
        Field[] fields = clazz.getDeclaredFields();
        StringBuilder text = new StringBuilder();

        for (Field field : fields) {
            field.setAccessible(true);

            try {
                Object value = field.get(obj);
                
                
                if (field.getName().equals("dob") || field.getName().equals("kinDob")) {
                	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                	if (value instanceof String) {
                        value = sdf.parse((String) value);
                    } else if (value instanceof Date) {
                        value = sdf.format((Date) value);
                    }
                }
                text.append(value + ",");
                System.out.println(field.getName() + ": " + value);
                
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (ParseException e) {
				e.printStackTrace();
			}
        }
        
        return text.toString();
	}
	
	public static Boolean saveUser(UserModel user) {
		try {
			File file = new  File("data/user.txt");
			
			if (file.exists()) {
				BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
				String userRow = getAllFields(user);
				userRow = userRow.substring(0, userRow.length() - 1) + "\n";
				writer.append(userRow);
				writer.close();
				return true;
			}else {
				return false;
			}
		}catch(IOException e) {
			return false;
		}
	}
	
	public static ArrayList<UserModel> getAllUsers() {
		ArrayList<UserModel> users = new ArrayList<>();
		
		try {
			File file = new  File("data/user.txt");
			
			if (file.exists()) {
				
				try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        String[] fields = line.trim().strip().split(",");
                        UserModel user = new UserModel();
                        
                        user.setId(Integer.parseInt(fields[0]));
                        user.setFirstName(fields[1]);
                        user.setLastName(fields[2]);
                        user.setEmail(fields[3]);
                        user.setPhNumber(Long.parseLong(fields[4]));
                        user.setMedicalConditions(fields[5]);
                        
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        try {
							user.setDob(sdf.parse(fields[6]));
							user.setKinDob(sdf.parse(fields[13]));
						} catch (ParseException e) {
							e.printStackTrace();
						}
                        
                        user.setGender(fields[7]);
                        user.setPassword(fields[8]);
                        user.setKinFirstName(fields[9]);
                        user.setKinLastName(fields[10]);
                        user.setKinEmail(fields[11]);
                        user.setKinPhNumber(Long.parseLong(fields[12]));
                        
                        users.add(user);
                    }
                }
				return users;
			}else {
				return users;
			}
		}catch(IOException e) {
			return users;
		}
	}
	
	public static ArrayList<HospitalModel> getAllHospitals() {
		ArrayList<HospitalModel> hospitals = new ArrayList<>();
		
		try {
			File file = new  File("data/hospital-info.csv");
			
			if (file.exists()) {
				
				try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        
                        try {
                            List<CSVRecord> records = parseCSV(line);
                            for (CSVRecord record : records) {
                            	HospitalModel hospital = new HospitalModel();
                            	hospital.setProviderId(Integer.parseInt(record.get(0)));
                                hospital.setHospitalName(record.get(1));
                                hospital.setAddress(record.get(2));
                                hospital.setCity(record.get(3));
                                hospital.setState(record.get(4));
                                hospital.setZipCode(record.get(5));
                                hospital.setCoutnry(record.get(6));
                                hospital.setPhNumber(Long.parseLong(record.get(7)));
                                hospital.setType(record.get(8));
                                hospital.setOwnership(record.get(9));
                                hospital.setHasEmergencyService(record.get(10));
                                
                                try {
                                	hospital.setRating(Double.parseDouble(record.get(11)));
                                }catch(NumberFormatException e) {
                                	hospital.setRating(0);
                                }
                                
                                hospitals.add(hospital);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
				return hospitals;
			}else {
				return hospitals;
			}
		}catch(IOException e) {
			return hospitals;
		}
	}
	
    public static List<CSVRecord> parseCSV(String csvData) throws IOException {
        StringReader reader = new StringReader(csvData);
        try (CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT)) {
			return parser.getRecords();
		}
    }
    
    public static Boolean saveAppointment(AppointmentModel appointment) {
		try {
			File file = new  File("data/appointments.txt");
			
			if (file.exists()) {
				BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
				String row = getAllFields(appointment);
				row = row.substring(0, row.length() - 1) + "\n";
				writer.append(row);
				writer.close();
				return true;
			}else {
				return false;
			}
		}catch(IOException e) {
			return false;
		}
	}
    
    public static String generateAppointmentId() {
    	final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        final String DIGITS = "0123456789";
        final SecureRandom RANDOM = new SecureRandom();
        StringBuilder sb = new StringBuilder();

        char randomLetter = LETTERS.charAt(RANDOM.nextInt(LETTERS.length()));
        sb.append(randomLetter);
        
        for (int i = 0; i < 6; i++) {
            char randomDigit = DIGITS.charAt(RANDOM.nextInt(DIGITS.length()));
            sb.append(randomDigit);
        }
        return sb.toString();
    }
    
    public static ArrayList<AppointmentModel> getAllAppointments(){
    	ArrayList<AppointmentModel> appointments = new ArrayList<AppointmentModel>();
    	
    	try {
			File file = new  File("data/appointments.txt");
			
			if (file.exists()) {
				
				try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        String[] fields = line.trim().strip().split(",");
                        AppointmentModel appointment = new AppointmentModel();
                        
                        System.out.print(line);
                        appointment.setId(fields[0]);
                        appointment.setPatientId(Integer.parseInt(fields[1]));
                        appointment.setDiagnosis(fields[2]);
                        appointment.setHospitalId(Integer.parseInt(fields[3]));
                        appointment.setStatus(fields[4]);
                        
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
                        appointment.setDateTime(LocalDateTime.parse(fields[5], formatter));
                        
                        getAllFields(appointment);
                        appointments.add(appointment);
                    }
                }
				return appointments;
			}else {
				return appointments;
			}
		}catch(IOException e) {
			return appointments;
		}
    }
    
    public static AppointmentModel getAppointment(String id) {
    	ArrayList<AppointmentModel> appointments = getAllAppointments();

    	for (AppointmentModel a : appointments) {
    		if (a.getId().equals(id)) {
    			return a;
    		}
    	}
    	return null;
    }
    
    public static UserModel findUser(int id) {
    	ArrayList<UserModel> users = getAllUsers();
    	
    	for (UserModel user : users) {
    		if (user.getId() == id) {
    			return user;
    		}
    	}
    	return null;
    }
    
    public Boolean updateUser(UserModel user) {
    	try {
			File file = new  File("data/user.txt");
			
			if (file.exists()) {
				
				try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        String[] fields = line.trim().strip().split(",");
                    }
				}
				return true;
			}else {
				return false;
		}
    }catch (Exception e) {
    	e.printStackTrace();
    	return false;
    	}
    }
}