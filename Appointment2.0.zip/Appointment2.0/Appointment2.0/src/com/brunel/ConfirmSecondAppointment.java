package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.DatePanel;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

public class ConfirmSecondAppointment extends BaseWindow{

	private JFrame frame;
	private TextInput textField;

	public ConfirmSecondAppointment() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("<html><body><p>Enter Patient Information to book Second Appointment</p></body></html>");
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setBounds(82, 112, 1253, 161);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Please Confirm To Continue");
		lblNewLabel_1.setForeground(new Color(222, 221, 218));
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_1.setBounds(82, 302, 587, 50);
		panel.add(lblNewLabel_1);
		
		textField = new TextInput(8, "First Name");
		textField.setBounds(82, 398, 534, 54);
		panel.add(textField);
		textField.setColumns(10);
		
		TextInput txtnptLastName = new TextInput(8, "Last Name");
		txtnptLastName.setColumns(10);
		txtnptLastName.setBounds(801, 398, 534, 54);
		panel.add(txtnptLastName);
		
		TextInput txtnptEmail = new TextInput(8, "Email");
		txtnptEmail.setColumns(10);
		txtnptEmail.setBounds(82, 509, 534, 54);
		panel.add(txtnptEmail);
		
		TextInput txtnptMobileNumber = new TextInput(8, "Mobile Number");
		txtnptMobileNumber.setColumns(10);
		txtnptMobileNumber.setBounds(801, 509, 534, 54);
		panel.add(txtnptMobileNumber);
		
		TextInput txtnptAnyNewIssues = new TextInput(8, "Any New Issues");
		txtnptAnyNewIssues.setText("Any New Issues");
		txtnptAnyNewIssues.setColumns(10);
		txtnptAnyNewIssues.setBounds(82, 613, 534, 54);
		panel.add(txtnptAnyNewIssues);
		
		DatePanel dob = new DatePanel(frame, "Date of Birth");
		dob.setBounds(801, 613, 534, 54);
		
		panel.add(dob);
		
		RoundedButton btnNewButton = new RoundedButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SecondAppointmentSuccess().getFrame().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 29));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(83, 101, 119));
		btnNewButton.setBounds(190, 750, 308, 56);
		panel.add(btnNewButton);
		
		RoundedButton rndbtnChangeHospital = new RoundedButton("Update");
		rndbtnChangeHospital.setText("Change Hospital");
		rndbtnChangeHospital.setForeground(Color.WHITE);
		rndbtnChangeHospital.setFont(new Font("Dialog", Font.BOLD, 29));
		rndbtnChangeHospital.setBackground(new Color(83, 101, 119));
		rndbtnChangeHospital.setBounds(923, 750, 308, 56);
		panel.add(rndbtnChangeHospital);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
