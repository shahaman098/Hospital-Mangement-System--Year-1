package com.brunel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.RoundedButton;
import com.brunel.components.RoundedTextArea;
import com.brunel.components.TextInput;

public class FeedbackForm extends BaseWindow{

	private JFrame frame;
	private TextInput textField;
	
	public FeedbackForm() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Feedback Form");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 75));
		lblNewLabel.setBounds(500, 113, 609, 129);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Send us a message");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 40));
		lblNewLabel_1.setBounds(583, 280, 389, 55);
		panel.add(lblNewLabel_1);
		
		textField = new TextInput(8, "First Name");
		textField.setBounds(296, 390, 436, 63);
		panel.add(textField);
		textField.setColumns(10);
		
		TextInput txtnptLastName = new TextInput(8, "Last Name");
		txtnptLastName.setColumns(10);
		txtnptLastName.setBounds(863, 390, 436, 63);
		panel.add(txtnptLastName);
		
		TextInput txtnptMobileNumber = new TextInput(8, "Mobile Number");
		txtnptMobileNumber.setColumns(10);
		txtnptMobileNumber.setBounds(296, 501, 436, 63);
		panel.add(txtnptMobileNumber);
		
		TextInput txtnptEmail = new TextInput(8, "Email");
		txtnptEmail.setColumns(10);
		txtnptEmail.setBounds(863, 501, 436, 63);
		panel.add(txtnptEmail);
		
		RoundedTextArea textArea = new RoundedTextArea(3, 10);
		textArea.setFont(new Font("Dialog", Font.PLAIN, 26));
		textArea.setForeground(new Color(158, 158, 158));
		textArea.setText("Message");
		textArea.setBounds(296, 620, 1003, 167);
		panel.add(textArea);
		
		RoundedButton btnNewButton = new RoundedButton("Send");
		btnNewButton.setBackground(new Color(83, 101, 119));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 29));
		btnNewButton.setBounds(684, 844, 274, 67);
		panel.add(btnNewButton);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
