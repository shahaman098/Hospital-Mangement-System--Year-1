package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.AppointmentItemPanel;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

public class AppointmentCancel extends BaseWindow{

	private JFrame frame;
	
	public AppointmentCancel() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("Cancel an Appointment");
		panel_1.setBounds(534, 162, 645, 140);
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Enter your Appointment ID");
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setBounds(251, 335, 992, 106);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body><p>If you are sure to cancel please mention your Appointment Id which was</p><p>given to you at the time of booking the Appointment and kindly feel the</p><p>information.</p></body></html>");
		lblNewLabel_1.setForeground(new Color(192, 191, 188));
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_1.setBounds(251, 515, 672, 97);
		panel.add(lblNewLabel_1);
		
		TextInput textField = new TextInput(8, "Appointment ID");
		textField.setColumns(10);
		textField.setBounds(251, 624, 625, 63);
		panel.add(textField);
		
		TextInput txtnptReasonBehindThe = new TextInput(8, "Reason Behind the Cancellation");
		txtnptReasonBehindThe.setColumns(10);
		txtnptReasonBehindThe.setBounds(251, 721, 625, 63);
		panel.add(txtnptReasonBehindThe);
		
		RoundedButton btnNewButton = new RoundedButton("Confirm");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AppointmentCancelSuccess().getFrame().setVisible(true);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 29));
		btnNewButton.setBackground(new Color(83, 101, 119));
		btnNewButton.setBounds(712, 832, 308, 56);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("Please Confirm To Cancel");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_2.setForeground(new Color(192, 191, 188));
		lblNewLabel_2.setBounds(251, 453, 723, 50);
		panel.add(lblNewLabel_2);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
