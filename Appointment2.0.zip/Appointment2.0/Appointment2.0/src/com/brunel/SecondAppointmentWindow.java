package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.AppointmentItemPanel;
import com.brunel.components.RoundedButton;
import com.brunel.components.TextInput;

public class SecondAppointmentWindow extends BaseWindow{

	private JFrame frame;
	private TextInput textField;
	
	public SecondAppointmentWindow() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("Make a Second Appointment");
		panel_1.setBounds(448, 109, 645, 140);
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Enter your Appointment ID");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setForeground(new Color(13, 41, 74));
		lblNewLabel.setBounds(162, 289, 992, 106);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body><p>Please note that you can schedule a second appointment </br>only after a period of one month has passed since your first appointment.</p></body></html>");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_1.setBounds(162, 407, 1062, 157);
		panel.add(lblNewLabel_1);
		
		textField = new TextInput(8, "Appointment ID");
		textField.setBounds(162, 576, 625, 63);
		panel.add(textField);
		textField.setColumns(10);
		
		TextInput txtnptReasonBehindThe = new TextInput(8, "Reason Behind the Second Appointment");
		txtnptReasonBehindThe.setColumns(10);
		txtnptReasonBehindThe.setBounds(162, 673, 625, 63);
		panel.add(txtnptReasonBehindThe);
		
		RoundedButton btnNewButton = new RoundedButton("Confirm");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ConfirmSecondAppointment().getFrame().setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(83, 101, 119));
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 29));
		btnNewButton.setBounds(346, 778, 308, 56);
		panel.add(btnNewButton);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
