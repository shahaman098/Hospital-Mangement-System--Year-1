package com.brunel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import models.AppointmentModel;

public class BookingConfirmWindow extends BaseWindow {

	private JFrame frame;

	public BookingConfirmWindow(AppointmentModel appointment) {
		super();
		setAppointment(appointment);
		this.frame = super.getFrame();
		initialize(getAppointment());
	}

	private void initialize(AppointmentModel appointment) {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 900);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Booking Confirmation");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setBounds(472, 93, 448, 65);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 184, 0));
		panel_1.setBounds(103, 190, 1082, 684);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body style='text-align:center;'><p>Your Booking is confirmed at</p><p>the given time:</p></body></html>");
		lblNewLabel_1.setBounds(265, 60, 577, 110);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(null);
		panel_2.setBounds(352, 250, 346, 172);
		panel_1.add(panel_2);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a");
		JLabel lblNewLabel_3 = new JLabel(formatter.format(appointment.getDateTime().toLocalTime()));
		lblNewLabel_3.setOpaque(true);
		lblNewLabel_3.setHorizontalAlignment(SwingUtilities.CENTER);
		lblNewLabel_3.setPreferredSize(new Dimension(panel_2.getWidth(), 75));
		lblNewLabel_3.setBackground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 64));
		panel_2.add(lblNewLabel_3);
		
		formatter = DateTimeFormatter.ofPattern("EEEE, dd MMMM");
		
		JLabel lblNewLabel_4 = new JLabel(formatter.format(appointment.getDateTime()));
		lblNewLabel_4.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_2.add(lblNewLabel_4);
		
		String id = generateAppointmentId();
		ArrayList<AppointmentModel> appointments = getAllAppointments();
		
		for (AppointmentModel a : appointments) {
			if (a.getId().equals(id)) {
				id = generateAppointmentId();
			}
		}
		
		JLabel lblNewLabel_1_1 = new JLabel("<html><body style='text-align:center;'><p>Your Appointment ID is</p><p>: " + id + "</p></body></html>");
		lblNewLabel_1_1.setBounds(280, 512, 466, 110);
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD, 40));
		
		
		appointment.setId(id);
		panel_1.add(lblNewLabel_1_1);
		saveAppointment(appointment);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
