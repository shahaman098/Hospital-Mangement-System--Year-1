package com.brunel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.brunel.components.AppointmentItemPanel;
import com.brunel.components.RoundedButton;

import models.AppointmentModel;
import models.UserModel;

public class AppointmentBooking extends BaseWindow{

	private JFrame frame;
	private String selectedTime = "";
	private String selectedMonth = "";
	private String currentDay = "";
	
	public AppointmentBooking(UserModel user) {
		super();
		this.setUser(user);
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		AppointmentItemPanel panel_1 = new AppointmentItemPanel("Appointment Booking");
		panel_1.setBounds(386, 91, panel_1.getWidth(), panel_1.getHeight());
		
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Months Open");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setBounds(549, 260, 258, 47);
		panel.add(lblNewLabel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(42, 319, 1358, 150);
		panel.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 6, 25, 25));
		
		JLabel lblDays = new JLabel("Days");
		lblDays.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		lblDays.setBounds(635, 481, 99, 47);
		panel.add(lblDays);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setBounds(42, 540, 1358, 448);
		panel.add(panel_2_1);
		panel_2_1.setLayout(new GridLayout(0, 7, 25, 25));
		
		RoundedButton btnNewButton = new RoundedButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				AppointmentModel appointment = new AppointmentModel();
				UserModel user = getUser();
				appointment.setPatientId(user.getId());
				
				LocalDate date= LocalDate.now();
				LocalTime time = null; 
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a");
				
				try {
		            time = LocalTime.parse(selectedTime, formatter);
		        } catch (DateTimeParseException ex) {
		            ex.printStackTrace();
		        }
				
				LocalDateTime dateTime = date.atTime(time);
				appointment.setDateTime(dateTime);
				
				new SearchingHospital(appointment).getFrame().setVisible(true);
			}
		});
		
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(53, 132, 228));
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 26));
		btnNewButton.setBounds(1237, 112, 163, 75);
		panel.add(btnNewButton);
		
		String[] months = {
	            "January", "February", "March", "April", "May", "June", 
	            "July", "August", "September", "October", "November", "December"
	        };
		
		for (String month : months) {
			JLabel lbl = new JLabel(month);
			lbl.setOpaque(true);
			lbl.setFont(new Font("Dialog", Font.BOLD, 24));
			lbl.setHorizontalAlignment(SwingConstants.CENTER);
			lbl.setVerticalAlignment(SwingConstants.CENTER);
			lbl.setBackground(new Color(196, 196, 196));
			
			lbl.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					selectedMonth = lbl.getText();
					Component[] monthComponents = panel_2.getComponents();
					for (Component c : monthComponents) {
						if (c instanceof JLabel) {
							JLabel lbl = (JLabel) c;
							if (selectedMonth.equals(lbl.getText())) {
								lbl.setForeground(Color.WHITE);
								lbl.setBackground(new Color(255, 184, 0));
								
							}else {
								lbl.setForeground(Color.BLACK);
								lbl.setBackground(new Color(196, 196, 196));
							}
						}
					}
				}
			});
			panel_2.add(lbl);
		}
		
	
		
		String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
		String[] timeIntervals = {
	            "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", 
	            "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", 
	            "5:00 PM", "6:00 PM"
	        };
		
		
		for (String day : daysOfWeek) {
			JPanel panel_3 = new JPanel();
			FlowLayout layout = (FlowLayout) panel_3.getLayout();
			layout.setVgap(10);
			panel_2_1.add(panel_3);
			
			JLabel lblNewLabel_1 = new JLabel(day);
			lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 26));
			panel_3.setBackground(new Color(255, 255, 255));			
			panel_3.add(lblNewLabel_1);
			
			for (String time : timeIntervals) {
				JLabel label = new JLabel(time);
				label.setPreferredSize(new Dimension(172, 30));
				label.setOpaque(true);
				label.setFont(new Font("Dialog", Font.BOLD, 20));
				label.setHorizontalAlignment(SwingConstants.CENTER);
				label.setVerticalAlignment(SwingConstants.CENTER);
				label.setBackground(new Color(196, 196, 196));
				
				label.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						selectedTime = label.getText();
						
						Component[] monthComponents = panel_3.getComponents();
						JLabel weekDay = (JLabel) monthComponents[0];
						
						
						for (Component c : monthComponents) {
							
							if (c instanceof JLabel) {
								JLabel lbl = (JLabel) c;
								if (selectedTime.equals(lbl.getText())) {
									currentDay = weekDay.getText();
									lbl.setForeground(Color.WHITE);
									lbl.setBackground(new Color(255, 184, 0));
									
								}else {
									lbl.setForeground(Color.BLACK);
									lbl.setBackground(new Color(196, 196, 196));
								}
							}
						}
					}
				});
				panel_3.add(label);
			}
			
			
		}
		
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
