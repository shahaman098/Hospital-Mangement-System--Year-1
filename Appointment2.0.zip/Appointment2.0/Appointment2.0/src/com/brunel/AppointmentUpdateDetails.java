package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brunel.auth.KinWindow;
import com.brunel.components.DatePanel;
import com.brunel.components.PasswordField;
import com.brunel.components.RoundedButton;
import com.brunel.components.RoundedComboBoxUI;
import com.brunel.components.TextInput;

import models.AppointmentModel;
import models.UserModel;

public class AppointmentUpdateDetails extends BaseWindow{

	private JFrame frame;
	
	public AppointmentUpdateDetails(AppointmentModel appointment) {
		super();
		setAppointment(appointment);
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblEnterPatientInformation = new JLabel("Enter Patient Information to Update");
		lblEnterPatientInformation.setForeground(new Color(13, 41, 74));
		lblEnterPatientInformation.setFont(new Font("Dialog", Font.BOLD, 72));
		lblEnterPatientInformation.setBounds(124, 167, 1350, 99);
		panel.add(lblEnterPatientInformation);
		
		JLabel lblNewLabel_8 = new JLabel("Please Confirm To Continue");
		lblNewLabel_8.setForeground(new Color(192, 191, 188));
		lblNewLabel_8.setFont(new Font("Dialog", Font.BOLD, 36));
		lblNewLabel_8.setBounds(124, 278, 488, 50);
		panel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel();
		lblNewLabel_9.setText("<html><p>Please update us with your latest identity with whom we will be</p><p>able to contact you and your family.</p></html>");
		lblNewLabel_9.setForeground(new Color(158, 158, 158));
		lblNewLabel_9.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel_9.setBounds(124, 337, 607, 50);
		panel.add(lblNewLabel_9);
		
		TextInput fName = new TextInput(8, "Updated First Name");
		fName.setBounds(124, 423, 534, 60);
		panel.add(fName);
		
		TextInput lName = new TextInput(8, "Updated Last Name");
		lName.setBounds(800, 423, 534, 60);
		panel.add(lName);
		
		TextInput email = new TextInput(8, "Updated Email");
		email.setBounds(124, 513, 534, 60);
		panel.add(email);
		
		TextInput ph_number = new TextInput(8, "Updated Mobile Number");
		ph_number.setBounds(800, 513, 534, 60);
		panel.add(ph_number);
		
		TextInput medical_problem = new TextInput(8, "Updated Diagnosis");
		medical_problem.setBounds(124, 605, 534, 60);
		panel.add(medical_problem);
		
		DatePanel calendarPanel = new DatePanel(frame, "Updated Date of Birth");
		calendarPanel.setBounds(800, 605, 534, 60);
		panel.add(calendarPanel);
		
		String genders[] = {"Male", "Female", "Others"}; 
		
		JComboBox gender = new JComboBox(genders);
		gender.setForeground(new Color(158, 158, 158));
		gender.setFont(new Font("Arial", Font.PLAIN, 26));
		gender.setBackground(Color.WHITE);
		gender.setUI(new RoundedComboBoxUI());
		gender.setBounds(125, 709, 342, 60);
		panel.add(gender);
		
		PasswordField password = new PasswordField(8, "Password");
		password.setBounds(568, 709, 342, 60);
		panel.add(password);
		
		PasswordField c_password = new PasswordField(8, "Confirm Password");
		c_password.setBounds(992, 709, 342, 60);
		panel.add(c_password);
		
		RoundedButton signUp = new RoundedButton("Sign Up");
		signUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> errors = new ArrayList<String>();
				AppointmentModel appointment = getAppointment();
				UserModel user = findUser(appointment.getPatientId());
				
				String updatedFirstName = fName.getText();
				String updatedLastName = lName.getText();
				String updatedEmail = email.getText();
				Long updatedPhNumber = Long.parseLong(ph_number.getText());
				String updatedMedicalProblems = medical_problem.getText();
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date dob = null;

				try {
					dob = sdf.parse(calendarPanel.getDate());
				} catch (ParseException e1) {
					dob = null;
				}
				
				Date updatedDob = dob;
				String updatedGender = gender.getSelectedItem().toString();
				String pwd = new String(password.getPassword());
				String cpwd = new String(c_password.getPassword());
				
				if (updatedFirstName.isEmpty() || updatedLastName.isEmpty() || updatedEmail.isEmpty() || updatedPhNumber == 0
						|| updatedMedicalProblems.isEmpty() || updatedGender.isEmpty() || pwd.isEmpty() || cpwd.isEmpty()
						|| updatedDob == null) {
					errors.add("All fields need to filled before moving on.");
				} else if (!pwd.equals(cpwd)) {
					errors.add("Password and Confirm Passowrd must be same.");
				}

				if (!errors.isEmpty()) {
					JOptionPane.showMessageDialog(frame, errors.getFirst(), "Validation Error",
							JOptionPane.ERROR_MESSAGE);
					errors.removeFirst();
					return;
				} else {
					user.setFirstName(updatedFirstName);
					user.setLastName(updatedLastName);
					user.setEmail(updatedEmail);
					user.setPhNumber(updatedPhNumber);
					user.setMedicalConditions(updatedMedicalProblems);
					user.setGender(updatedGender);
					user.setPassword(pwd);
					user.setDob(updatedDob);

					ArrayList<UserModel> users = getAllUsers();
					Boolean isExist = false;

					updateUser(user);
				}
				
				new AppointmentUpdateConfirmation().getFrame().setVisible(true);
			}
		});
		signUp.setText("Next");
		signUp.setForeground(Color.WHITE);
		signUp.setFont(new Font("Dialog", Font.BOLD, 29));
		signUp.setBackground(new Color(83, 101, 119));
		signUp.setBounds(580, 848, 308, 56);
		panel.add(signUp);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
