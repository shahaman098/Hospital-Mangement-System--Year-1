package com.brunel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.brunel.components.AppointmentItemPanel;

import models.UserModel;

public class AppointmentWindow extends BaseWindow{

	private JFrame frame;
	
	public AppointmentWindow(UserModel user) {
		super();
		this.setUser(user);
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		
		panel.setSize(1440, 800);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Appointments");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 72));
		lblNewLabel.setBounds(141, 101, 536, 99);
		panel.add(lblNewLabel);
		
		AppointmentItemPanel schedulePanel = new AppointmentItemPanel("Schedule an Appointment");
		schedulePanel.setBounds(213, 237, 608, 140);
		schedulePanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				UserModel user = getUser();
				new ScheduleAppointment(user).getFrame().setVisible(true);
			}
		});
		panel.add(schedulePanel);
		
		AppointmentItemPanel updatePanel = new AppointmentItemPanel("Update an Appointment");
		updatePanel.setBounds(213, 407, 608, 140);
		updatePanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				UserModel user = getUser();
				new AppointmentUpdate(user).getFrame().setVisible(true);
			}
		});
		panel.add(updatePanel);
		
		AppointmentItemPanel cancelPanel = new AppointmentItemPanel("Cancel an Appointment");
		cancelPanel.setBounds(213, 581, 608, 140);
		cancelPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new AppointmentCancel().getFrame().setVisible(true);
			}
		});
		panel.add(cancelPanel);
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
