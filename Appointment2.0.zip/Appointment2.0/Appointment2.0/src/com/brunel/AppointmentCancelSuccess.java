package com.brunel;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class AppointmentCancelSuccess extends BaseWindow{

	private JFrame frame;
	
	public AppointmentCancelSuccess() {
		super();
		this.frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setSize(1440, 1000);
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCancellationConfirmation = new JLabel("Cancellation Confirmation");
		lblCancellationConfirmation.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 46));
		lblCancellationConfirmation.setBounds(459, 112, 595, 73);
		panel.add(lblCancellationConfirmation);
		
		JPanel panel_1 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setVgap(50);
		panel_1.setBackground(new Color(255, 184, 0));
		panel_1.setBounds(168, 216, 1149, 684);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("<html><body style='text-align:center;'><p>You booking has been</p><p>cancelled</p></body></html>");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(getClass().getResource("/images/checkmark.png")));
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("<html><body style='text-align:center;'><p>Your Appointment ID:</p><p>B230838 is no longer Valid</p></body></html>");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD, 40));
		panel_1.add(lblNewLabel_1_1);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

}
