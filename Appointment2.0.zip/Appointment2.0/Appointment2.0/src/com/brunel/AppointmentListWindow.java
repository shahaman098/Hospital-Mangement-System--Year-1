package com.brunel;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.brunel.components.HospitalCard;
import com.brunel.components.RoundedButton;
import com.brunel.components.RoundedPanel;
import com.brunel.components.WrapLayout;

import models.AppointmentModel;
import models.HospitalModel;
import javax.swing.JScrollPane;

public class AppointmentListWindow extends BaseWindow {

	public JFrame frame;
	private JTextField txtSearch;
	
	public AppointmentListWindow(AppointmentModel appointment) {
		super();
		setAppointment(appointment);
		frame = super.getFrame();
		initialize();
	}

	private void initialize() {
		JPanel main = new JPanel();
		main.setBackground(new Color(255, 255, 255));
		main.setLayout(null);
		main.setSize(1440, 1000);
		
		frame.getContentPane().add(main);
		
		JLabel lblNewLabel = new JLabel("Available Dates");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setForeground(new Color(51, 51, 51));
		lblNewLabel.setBounds(84, 117, 338, 60);
		main.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(845, 129, 436, 60);
		panel.setBorder(null);
		main.add(panel);
		panel.setLayout(null);
		
		RoundedPanel panel_1 = new RoundedPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(10, 5, 319, 44);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(getClass().getResource("/images/search.png")));
		
		txtSearch = new JTextField(8);
		txtSearch.setFont(new Font("Dialog", Font.PLAIN, 14));
		txtSearch.setSize(200, 44);
		panel_1.add(txtSearch);
		txtSearch.setBorder(new EmptyBorder(5, 25, 5, 15));
		txtSearch.setText("Search");
		txtSearch.setColumns(15);
		
		RoundedButton btnSearch = new RoundedButton("Search");
		btnSearch.setBounds(341, 5, 85, 44);
		panel.add(btnSearch);
		btnSearch.setForeground(new Color(46, 194, 126));
		btnSearch.setBackground(new Color(83, 101, 119));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 290, 1008, 307);
		
		panel_2.setLayout(new WrapLayout(FlowLayout.CENTER, 15, 15));
		
		ArrayList<HospitalModel> hospitals = getAllHospitals();
		
		for(HospitalModel hospital : hospitals) {
			try {
				HospitalCard hospital_card = new HospitalCard(getClass().getResource("/images/hospital.png"), hospital.getHospitalName(), hospital.getType(), hospital.getAddress(), hospital.getRating());
				System.out.println(hospital_card.getBounds());
				hospital_card.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						AppointmentModel appointment = getAppointment();
						System.out.println(appointment.getDateTime());
						System.out.println(appointment.getPatientId());
						System.out.println(hospital.getProviderId());
						System.out.println(hospital.getHospitalName());
						
						appointment.setHospitalId(hospital.getProviderId());
						appointment.setDiagnosis(hospital.getType());
						appointment.setStatus("Pending");
						
						new BookingConfirmWindow(appointment).getFrame().setVisible(true);
					}
				});
				
				if (hospitals.indexOf(hospital) == 30) {
					break;
				} 
				panel_2.add(hospital_card);
			} catch (Exception e) {
				return;
			}
			
		}
		System.out.println(panel_2.getComponentCount());
		main.add(panel_2);
		
		JScrollPane scrollPane = new JScrollPane(panel_2);
		scrollPane.setBounds(78, 215, 1203, 751);
		JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
        verticalScrollBar.setUnitIncrement(16);
        verticalScrollBar.setBlockIncrement(64);
		
		main.add(scrollPane);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
