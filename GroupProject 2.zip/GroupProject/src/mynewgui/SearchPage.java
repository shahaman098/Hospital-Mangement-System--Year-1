package mynewgui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.List;

public class SearchPage extends JFrame {
    private JTextField searchField;
    private JTextArea resultArea;
    private JButton searchButton;
    private JButton exitButton;

    public SearchPage() {
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Search Records");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //  close
        setLocationRelativeTo(null); // MIDDLE
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue
        setLayout(new BorderLayout());

        // Load logo image
        URL logoURL = getClass().getResource("/resources/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, BorderLayout.NORTH);
        } else {
            System.err.println("Logo image not found.");
        }

        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.setBackground(new Color(240, 248, 255)); // Light blue 
        searchPanel.add(createLabel("Enter Search Term:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchButton = createButton("Search");
        searchButton.addActionListener(this::performSearch);
        searchPanel.add(searchButton);
        add(searchPanel, BorderLayout.NORTH);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // Add exit button at the bottom
        exitButton = createButton("Exit");
        exitButton.addActionListener(this::exitSearchPage);
        JPanel exitPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        exitPanel.setBackground(new Color(240, 248, 255)); // Light blue 
        exitPanel.add(exitButton);
        add(exitPanel, BorderLayout.SOUTH);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(new Color(70, 130, 180));
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private void performSearch(ActionEvent e) {
        String searchTerm = searchField.getText().trim();
        if (searchTerm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<String[]> results = Storage.searchPersonData(searchTerm);
        if (results.isEmpty()) {
            resultArea.setText("No records found for search term: " + searchTerm);
        } else {
            StringBuilder sb = new StringBuilder();
                     for (String[] record : results) {
                sb.append(String.join(", ", record)).append("\n");
            }
            resultArea.setText(sb.toString());
        }
    }

    private void exitSearchPage(ActionEvent e) {
        dispose(); // Close only the search page window
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SearchPage().setVisible(true));
    }
}

