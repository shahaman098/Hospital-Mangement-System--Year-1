package mynewgui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CalculationsPage extends JFrame {
    private JLabel ageLabel, freeMealLabel, adultAccompanimentLabel, paediatricDoctorLabel, visitationNumberLabel, extraSupportLabel;
    private String username, firstName, lastName, dob, phone, email, address, city, postalCode, ailment, kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone, disabilities;

    public CalculationsPage(String username, String firstName, String lastName, String dob, String phone, String email, String address, String city, String postalCode, String ailment, String kinFirstName, String kinLastName, String kinPatientName, String kinDob, String kinAddress, String kinPhone, String disabilities) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.city = city;
        this.postalCode = postalCode;
        this.ailment = ailment;
        this.kinFirstName = kinFirstName;
        this.kinLastName = kinLastName;
        this.kinPatientName = kinPatientName;
        this.kinDob = kinDob;
        this.kinAddress = kinAddress;
        this.kinPhone = kinPhone;
        this.disabilities = disabilities;
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Calculations Page");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // MIDDLE WINDOW
        getContentPane().setBackground(new Color(240, 248, 255)); 
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        int age = calculateAge(dob);
        ageLabel = new JLabel("Age: " + age);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(ageLabel, gbc);

        freeMealLabel = new JLabel("Free Meal: " + (age > 70 ? "Yes" : "No"));
        gbc.gridy = 1;
        add(freeMealLabel, gbc);

        adultAccompanimentLabel = new JLabel("Adult Accompaniment Required: " + (age < 18 ? "Yes" : "No"));
        gbc.gridy = 2;
        add(adultAccompanimentLabel, gbc);

        paediatricDoctorLabel = new JLabel("Paediatric Doctor Assignment: " + (age < 13 ? "Yes" : "No"));
        gbc.gridy = 3;
        add(paediatricDoctorLabel, gbc);

        String visitationNumber = generateVisitationNumber();
        visitationNumberLabel = new JLabel("Visitation Number: " + visitationNumber);
        gbc.gridy = 4;
        add(visitationNumberLabel, gbc);

        extraSupportLabel = new JLabel("Do they need extra support: " + (disabilities.isEmpty() ? "No" : "Yes"));
        gbc.gridy = 5;
        add(extraSupportLabel, gbc);

        // Save patient data
        savePatientData(firstName, lastName, dob, phone, email, address, city, postalCode, ailment, kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone, disabilities, visitationNumber);

        // Button to go back to the main screen
        JButton backButton = new JButton("Back to Main Screen");
        backButton.setBackground(new Color(173, 216, 230)); // Light blue button
        backButton.setForeground(Color.BLACK);
        backButton.addActionListener(e -> backToMainScreen());
        gbc.gridy = 6;
        add(backButton, gbc);
    }

    private int calculateAge(String dob) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate birthDate = LocalDate.parse(dob, formatter);
        LocalDate currentDate = LocalDate.now();
        return Period.between(birthDate, currentDate).getYears();
    }

    private String generateVisitationNumber() {
        return String.format("%08d", (int) (Math.random() * 100000000));
    }

    private void savePatientData(String firstName, String lastName, String dob, String phone, String email, String address, String city, String postalCode, String ailment, String kinFirstName, String kinLastName, String kinPatientName, String kinDob, String kinAddress, String kinPhone, String disabilities, String visitationNumber) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("patients.csv", true))) {
            writer.write(String.join(",",
            		username,
                    firstName,
                    lastName,
                    dob,
                    phone,
                    email,
                    address,
                    city,
                    postalCode,
                    ailment,
                    kinFirstName,
                    kinLastName,
                    kinPatientName,
                    kinDob,
                    kinAddress,
                    kinPhone,
                    disabilities,
                    visitationNumber));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving patient data.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void backToMainScreen() {
        new LoginScreen().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        // Sample data for testing
        SwingUtilities.invokeLater(() -> new CalculationsPage(
            "j", "J", "D", "1970-05-15", "1234567890", "j@example.com",
            "1 St", "town", "12345", "Flu", "Ja", "D", "J D", "1980-01-01", "4 St", "0987654321", "Visual Impairment").setVisible(true));
    }
}

