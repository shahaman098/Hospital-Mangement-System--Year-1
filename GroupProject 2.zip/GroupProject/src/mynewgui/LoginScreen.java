package mynewgui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

	public class LoginScreen extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton forgotPasswordButton;
    private JButton registerButton;
    private JButton searchButton;

    public LoginScreen() {
        initializeComponents();
    }

    
    
    
    private void initializeComponents() {
        setTitle("Login");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); //able to make them on middle
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue 
        setLayout(new BorderLayout());

        //  logo image
        URL logoURL = getClass().getResource("/images/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, BorderLayout.NORTH);
        } else {
            System.err.println("Logo image not found.");
        }

        
        
        
        
        JPanel formPanel = new JPanel();
        formPanel.setBackground(new Color(240, 248, 255)); // Light blue 
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(20, 50, 20, 50));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("LOGIN TO YOUR ACCOUNT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(70, 130, 180));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(titleLabel, gbc);

        JLabel usernameLabel = new JLabel("User Name");
        usernameLabel.setForeground(new Color(70, 130, 180));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(usernameLabel, gbc);

        usernameField = createTextField();
        gbc.gridx = 1;
        formPanel.add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);

        passwordField = createPasswordField();
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        loginButton = createButton("LOG IN");
        loginButton.addActionListener(this::performLogin);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(loginButton, gbc);

        forgotPasswordButton = createButton("Forgot Password");
        forgotPasswordButton.addActionListener(this::openForgotPasswordDialog);
        gbc.gridy = 4;
        formPanel.add(forgotPasswordButton, gbc);

        registerButton = createButton("REGISTER");
        registerButton.addActionListener(this::openRegisterForm);
        gbc.gridy = 5;
        formPanel.add(registerButton, gbc);

        searchButton = createButton("SEARCH RECORDS");
        searchButton.addActionListener(this::openSearchPage);
        gbc.gridy = 6;
        formPanel.add(searchButton, gbc);

        add(formPanel, BorderLayout.CENTER);
    }

    
    
    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        textField.setBackground(Color.WHITE);
        return textField;
    }

    
    
    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        passwordField.setBackground(Color.WHITE);
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private void performLogin(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (authenticate(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
            // Pass the necessary arguments to the CalculationsPage constructor
            new CalculationsPage(username, "J", "D", "1952-05-15", "1234567890", "j@example.com", "1 St", "town", "12345", "Flu", "Jane", "Doe", "J D", "1982-01-01", "4 St", "0987654321", "Visual Impairment").setVisible(true);
            dispose(); // Close window
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean authenticate(String username, String password) {
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials[0].equals(username) && credentials[1].equals(password)) {
                    return true;
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading users file", "File Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    private void openRegisterForm(ActionEvent e) {
        new PersonInfo().setVisible(true);
        dispose(); // Close window
    }

    private void openSearchPage(ActionEvent e) {
        new SearchPage().setVisible(true);
    }

    private void openForgotPasswordDialog(ActionEvent e) {
        new ForgotPasswordDialog(this).setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginScreen().setVisible(true));
    }
}
