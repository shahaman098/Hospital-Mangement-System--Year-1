package mynewgui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

public class Disabilities extends JFrame {
    private JCheckBox visualImpairmentCheckBox, hearingImpairmentCheckBox, mobilityImpairmentCheckBox, cognitiveImpairmentCheckBox;
    private JButton submitButton;
    private String username, firstName, lastName, dob, phone, email, address, city, postalCode, kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone;
    private Ailment ailment;

    public Disabilities(String username, String firstName, String lastName, String dob, String phone, String email, String address, String city, String postalCode, Ailment ailment, String kinFirstName, String kinLastName, String kinPatientName, String kinDob, String kinAddress, String kinPhone) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.city = city;
        this.postalCode = postalCode;
        this.ailment = ailment;
        this.kinFirstName = kinFirstName;
        this.kinLastName = kinLastName;
        this.kinPatientName = kinPatientName;
        this.kinDob = kinDob;
        this.kinAddress = kinAddress;
        this.kinPhone = kinPhone;
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Disabilities");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // MAKE THEM IN MIDDLE
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue 
        setLayout(new GridBagLayout());

        // Load logo image
        URL logoURL = getClass().getResource("/resources/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, new GridBagConstraints(0, 0, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 0, 10, 0), 0, 0));
        } else {
            System.err.println("Logo image not found.");
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        addCheckBox("Visual Impairment", visualImpairmentCheckBox = createCheckBox(), gbc, 1);
        addCheckBox("Hearing Impairment", hearingImpairmentCheckBox = createCheckBox(), gbc, 2);
        addCheckBox("Mobility Impairment", mobilityImpairmentCheckBox = createCheckBox(), gbc, 3);
        addCheckBox("Cognitive Impairment", cognitiveImpairmentCheckBox = createCheckBox(), gbc, 4);

        submitButton = createButton("Submit");
        submitButton.addActionListener(this::submitDisabilities);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(submitButton, gbc);

        JButton backButton = createButton("Back to Login");
        backButton.addActionListener(e -> backToLogin());
        gbc.gridy = 6;
        add(backButton, gbc);
    }

    private void addCheckBox(String text, JCheckBox checkBox, GridBagConstraints gbc, int yPos) {
        checkBox = new JCheckBox(text);
        checkBox.setBackground(new Color(240, 248, 255)); // Light blue background
        checkBox.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = yPos;
        add(checkBox, gbc);
    }

    private JCheckBox createCheckBox() {
        JCheckBox checkBox = new JCheckBox();
        checkBox.setBackground(new Color(240, 248, 255)); // Light blue background
        return checkBox;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private void submitDisabilities(ActionEvent e) {
        StringBuilder selectedDisabilities = new StringBuilder();

        if (visualImpairmentCheckBox.isSelected()) {
            selectedDisabilities.append("Visual Impairment, ");
        }
        if (hearingImpairmentCheckBox.isSelected()) {
            selectedDisabilities.append("Hearing Impairment, ");
        }
        if (mobilityImpairmentCheckBox.isSelected()) {
            selectedDisabilities.append("Mobility Impairment, ");
        }
        if (cognitiveImpairmentCheckBox.isSelected()) {
            selectedDisabilities.append("Cognitive Impairment, ");
        }

        // Remove the last comma and space
        if (selectedDisabilities.length() > 0) {
            selectedDisabilities.setLength(selectedDisabilities.length() - 2);
        }

        String disabilities = selectedDisabilities.toString();
        JOptionPane.showMessageDialog(this, "Disabilities Submitted Successfully.");

        // Save patient data to file
        savePatientData(username, firstName, lastName, dob, phone, email, address, city, postalCode, ailment, kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone, disabilities);

        new CalculationsPage(username, firstName, lastName, dob, phone, email, address, city, postalCode, ailment.getName(), kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone, disabilities).setVisible(true);

        dispose(); // Close the disabilities window
    }

    private void savePatientData(String username, String firstName, String lastName, String dob, String phone, String email, String address, String city, String postalCode, Ailment ailment, String kinFirstName, String kinLastName, String kinPatientName, String kinDob, String kinAddress, String kinPhone, String disabilities) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("patients.csv", true))) {
            writer.write(String.join(",",
                    username,
                    firstName,
                    lastName,
                    dob,
                    phone,
                    email,
                    address,
                    city,
                    postalCode,
                    ailment.getName(),
                    ailment.getDescription(),
                    kinFirstName,
                    kinLastName,
                    kinPatientName,
                    kinDob,
                    kinAddress,
                    kinPhone,
                    disabilities));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving patient data.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void backToLogin() {
        new LoginScreen().setVisible(true);
        dispose(); // Close the current window
    }

    public static void main(String[] args) {
        // Sample data for testing
        new Disabilities(
            "j", "J", "D", "1952-05-15", "1234567890", "j@example.com",
            "1 St", "town", "12345", new Ailment("Flu", "A common viral infection"),
            "J", "D", "J D", "1980-01-01", "4 St", "0987654321"
        ).setVisible(true);
    }
}
