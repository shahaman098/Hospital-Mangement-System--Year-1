package mynewgui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class KinDetails extends JFrame {
    private JTextField kinFirstNameField, kinLastNameField, kinPatientNameField, kinAddressField, kinPhoneField;
    private JComboBox<Integer> kinYearComboBox, kinMonthComboBox, kinDayComboBox;
    private JButton submitButton;
    private String username, firstName, lastName, dob, phone, email, address, city, postalCode;
    private Ailment ailment;

    public KinDetails(String username, String firstName, String lastName, String dob, String phone, String email, String address, String city, String postalCode, Ailment ailment) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.city = city;
        this.postalCode = postalCode;
        this.ailment = ailment;
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Kin's Information");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue 
        setLayout(new GridBagLayout());

        // logo image
        URL logoURL = getClass().getResource("/resources/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, new GridBagConstraints(0, 0, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 0, 10, 0), 0, 0));
        } else {
            System.err.println("Logo image not found.");
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        addLabelAndField("Kin's First Name:", kinFirstNameField = createTextField(), gbc, 1);
        addLabelAndField("Kin's Last Name:", kinLastNameField = createTextField(), gbc, 2);
        addLabelAndField("Patient Name:", kinPatientNameField = createTextField(), gbc, 3);
        addLabelAndField("Kin's Date of Birth:", createDatePanel(), gbc, 4);
        addLabelAndField("Kin's Address:", kinAddressField = createTextField(), gbc, 5);
        addLabelAndField("Kin's Phone:", kinPhoneField = createTextField(), gbc, 6);

        submitButton = createButton("Submit");
        submitButton.addActionListener(this::submitKinDetails);
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(submitButton, gbc);
    }

    private void addLabelAndField(String labelText, Component field, GridBagConstraints gbc, int yPos) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = yPos;
        add(label, gbc);
        gbc.gridx = 1;
        add(field, gbc);
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        textField.setBackground(Color.WHITE);
        return textField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private JPanel createDatePanel() {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBackground(new Color(240, 248, 255)); // Light blue 

        kinYearComboBox = new JComboBox<>(createYears().toArray(new Integer[0]));
        kinMonthComboBox = new JComboBox<>(createMonths().toArray(new Integer[0]));
        kinDayComboBox = new JComboBox<>(createDays(31).toArray(new Integer[0])); // EXTRA 31 days

        ActionListener updateDaysListener = e -> updateDays();
        kinYearComboBox.addActionListener(updateDaysListener);
        kinMonthComboBox.addActionListener(updateDaysListener);

        panel.add(kinYearComboBox);
        panel.add(kinMonthComboBox);
        panel.add(kinDayComboBox);
        return panel;
    }

    private List<Integer> createYears() {
        List<Integer> years = new ArrayList<>();
        for (int i = 1849; i <= 2024; i++) {
            years.add(i);
        }
        return years;
    }

    private List<Integer> createMonths() {
        List<Integer> months = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            months.add(i);
        }
        return months;
    }

    private List<Integer> createDays(int maxDays) {
        List<Integer> days = new ArrayList<>();
        for (int i = 1; i <= maxDays; i++) {
            days.add(i);
        }
        return days;
    }

    private void updateDays() {
        int year = (int) kinYearComboBox.getSelectedItem();
        int month = (int) kinMonthComboBox.getSelectedItem();
        int maxDays = getMaxDays(year, month);
        kinDayComboBox.setModel(new DefaultComboBoxModel<>(createDays(maxDays).toArray(new Integer[0])));
    }

    private int getMaxDays(int year, int month) {
        switch (month) {
            case 2:
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29; // February in a leap year
                }
                return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 31;
        }
    }

    private void submitKinDetails(ActionEvent e) {
        if (validateKinDetails()) {
            String kinFirstName = kinFirstNameField.getText();
            String kinLastName = kinLastNameField.getText();
            String kinPatientName = kinPatientNameField.getText();
            String kinDob = String.format("%04d-%02d-%02d", (Integer) kinYearComboBox.getSelectedItem(), (Integer) kinMonthComboBox.getSelectedItem(), (Integer) kinDayComboBox.getSelectedItem());
            String kinAddress = kinAddressField.getText();
            String kinPhone = kinPhoneField.getText();

            // NEXT TO kin data to the Disabilities screen
            new Disabilities(username, firstName, lastName, dob, phone, email, address, city, postalCode, ailment, kinFirstName, kinLastName, kinPatientName, kinDob, kinAddress, kinPhone).setVisible(true);
            dispose(); // Close the kin  window
        }
    }

    private boolean validateKinDetails() {
        if (!isValidName(kinFirstNameField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid kin's first name (letters only).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!isValidName(kinLastNameField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid kin's last name (letters only).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (kinPatientNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a patient's name.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (kinAddressField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a kin's address.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!isValidPhone(kinPhoneField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid kin's phone number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private boolean isValidName(String name) {
        return name.matches("[a-zA-Z]+");
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("\\d{10}|(?:\\d{3}-){2}\\d{4}");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new KinDetails("username", "John", "Doe", "1950-05-15", "1234567890", "john.doe@example.com", "123 Main St", "Anytown", "12345", new Ailment("Flu", "Influenza virus")).setVisible(true));
    }
}

