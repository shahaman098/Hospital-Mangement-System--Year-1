package mynewgui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AddAilmentDialog extends JDialog {
    private JTextField ailmentNameField, ailmentDescriptionField;
    private JButton addButton, cancelButton;

    public AddAilmentDialog(Frame parent) {
        super(parent, "Add Ailment", true);
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new GridLayout(3, 2));
        setSize(400, 200);

        add(new JLabel("Ailment Name:"));
        ailmentNameField = new JTextField(20);
        add(ailmentNameField);

        add(new JLabel("Ailment Description:"));
        ailmentDescriptionField = new JTextField(20);
        add(ailmentDescriptionField);

        addButton = new JButton("Add");
        addButton.setBackground(new Color(173, 216, 230)); // Light blue FOR button
        addButton.setForeground(Color.BLACK);
        addButton.addActionListener(this::addAilment);
        add(addButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(173, 216, 230)); // Light blue FOR button
        cancelButton.setForeground(Color.BLACK);
        cancelButton.addActionListener(e -> dispose());
        add(cancelButton);
    }

    private void addAilment(ActionEvent e) {
        String ailmentName = ailmentNameField.getText().trim();
        String ailmentDescription = ailmentDescriptionField.getText().trim();

        if (ailmentName.isEmpty() || ailmentDescription.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Both fields must be filled out.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ailments.csv", true))) {
            writer.write(ailmentName + "," + ailmentDescription);
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Ailment added successfully.");
            dispose();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving ailment.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
