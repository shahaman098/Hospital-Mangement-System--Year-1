package mynewgui;

import javax.swing.*;
import java.awt.*;

public class AilmentRenderer extends JLabel implements ListCellRenderer<Ailment> {

    public AilmentRenderer() {
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends Ailment> list, Ailment value, int index, boolean isSelected, boolean cellHasFocus) {
        setText(value.getName() + " - " + value.getDescription());
        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }
        return this;
    }
}
