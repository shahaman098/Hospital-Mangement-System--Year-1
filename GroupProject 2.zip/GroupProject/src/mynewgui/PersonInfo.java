package mynewgui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Vector;

public class PersonInfo extends JFrame {
    private JTextField firstNameField, lastNameField, usernameField, phoneField, emailField, addressField, cityField, postalCodeField;
    private JPasswordField passwordField;
    private JComboBox<Ailment> ailmentComboBox;
    private JButton registerButton, addAilmentButton;
    private JComboBox<Integer> yearComboBox, monthComboBox, dayComboBox;

    public PersonInfo() {
        initializeComponents();
        loadAilments();
    }

    private void initializeComponents() {
        setTitle("Person Information");
        setSize(850, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // make them middle
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue 
        setLayout(new BorderLayout());

        //  logo image
        URL logoURL = getClass().getResource("/images/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, BorderLayout.NORTH);
        } else {
            System.err.println("Logo image not found.");
        }

        JPanel formPanel = new JPanel();
        formPanel.setBackground(new Color(240, 248, 255)); // Light blue background
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(20, 50, 20, 50));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addLabelAndField("First Name:", firstNameField = createTextField(), formPanel, gbc, 0);
        addLabelAndField("Last Name:", lastNameField = createTextField(), formPanel, gbc, 1);
        addLabelAndField("Username:", usernameField = createTextField(), formPanel, gbc, 2);
        addLabelAndField("Password:", passwordField = createPasswordField(), formPanel, gbc, 3);
        addLabelAndField("Date of Birth:", createDatePanel(), formPanel, gbc, 4);
        addLabelAndField("Phone:", phoneField = createTextField(), formPanel, gbc, 5);
               addLabelAndField("Email:", emailField = createTextField(), formPanel, gbc, 6);
        addLabelAndField("Address:", addressField = createTextField(), formPanel, gbc, 7);
        addLabelAndField("City:", cityField = createTextField(), formPanel, gbc, 8);
        addLabelAndField("Postal Code:", postalCodeField = createTextField(), formPanel, gbc, 9);

        JLabel ailmentLabel = new JLabel("Ailment:");
        ailmentLabel.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = 10;
        formPanel.add(ailmentLabel, gbc);
        ailmentComboBox = new JComboBox<>();
        gbc.gridx = 1;
        formPanel.add(ailmentComboBox, gbc);

        addAilmentButton = createButton("Add Ailment");
        addAilmentButton.addActionListener(this::openAddAilmentDialog);
        gbc.gridy = 11;
        formPanel.add(addAilmentButton, gbc);

        registerButton = createButton("Register");
        registerButton.addActionListener(this::registerPerson);
        gbc.gridy = 12;
        formPanel.add(registerButton, gbc);

        add(formPanel, BorderLayout.CENTER);
    }

    private void addLabelAndField(String labelText, Component field, JPanel panel, GridBagConstraints gbc, int yPos) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = yPos;
        panel.add(label, gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        textField.setBackground(Color.WHITE);
        return textField;
    }

    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        passwordField.setBackground(Color.WHITE);
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private JPanel createDatePanel() {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBackground(new Color(240, 248, 255)); // Light blue 

        yearComboBox = new JComboBox<>(createYears());
        monthComboBox = new JComboBox<>(createMonths());
        dayComboBox = new JComboBox<>(createDays(31)); // go back to 31. days

        ActionListener updateDaysListener = e -> updateDays();
        yearComboBox.addActionListener(updateDaysListener);
        monthComboBox.addActionListener(updateDaysListener);

        panel.add(yearComboBox);
        panel.add(monthComboBox);
        panel.add(dayComboBox);
        return panel;
    }

    private Vector<Integer> createYears() {
        Vector<Integer> years = new Vector<>();
        for (int i = 1849; i <= 2024; i++) {
            years.add(i);
        }
        return years;
    }

    private Vector<Integer> createMonths() {
        Vector<Integer> months = new Vector<>();
        for (int i = 1; i <= 12; i++) {
            months.add(i);
        }
        return months;
    }

    private Vector<Integer> createDays(int maxDays) {
        Vector<Integer> days = new Vector<>();
        for (int i = 1; i <= maxDays; i++) {
            days.add(i);
        }
        return days;
    }

    private void updateDays() {
        int year = (int) yearComboBox.getSelectedItem();
        int month = (int) monthComboBox.getSelectedItem();
        int maxDays = getMaxDays(year, month);
        dayComboBox.setModel(new DefaultComboBoxModel<>(createDays(maxDays)));
    }

    private int getMaxDays(int year, int month) {
        switch (month) {
            case 2:
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29; // extra day leap year
                }
                return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 31;
        }
    }

    private void loadAilments() {
        ailmentComboBox.removeAllItems(); // Clear  items
        try (BufferedReader br = new BufferedReader(new FileReader("ailments.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    ailmentComboBox.addItem(new Ailment(parts[0], parts[1]));
                }
            }
            ailmentComboBox.setRenderer(new AilmentRenderer()); // Set  renderer
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading ailments file.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openAddAilmentDialog(ActionEvent e) {
        new AddAilmentDialog(this).setVisible(true);
        loadAilments(); // Refresh the ailments list after the adding a new ailment
    }

    private void registerPerson(ActionEvent e) {
        if (validateInput()) {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String dob = String.format("%04d-%02d-%02d", (Integer) yearComboBox.getSelectedItem(), (Integer) monthComboBox.getSelectedItem(), (Integer) dayComboBox.getSelectedItem());
            String phone = phoneField.getText();
            String email = emailField.getText();
            String address = addressField.getText();
            String city = cityField.getText();
            String postalCode = postalCodeField.getText();
            Ailment ailment = (Ailment) ailmentComboBox.getSelectedItem();

            saveRegistrationData(firstName, lastName, username, password, dob, phone, email, address, city, postalCode, ailment);
            new KinDetails(username, firstName, lastName, dob, phone, email, address, city, postalCode, ailment).setVisible(true); // next to KinDetails
            dispose(); // go to next window
        }
    }

    private boolean validateInput() {
        // Validate first name
        if (!isValidName(firstNameField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid first name (letters only).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate last name
        if (!isValidName(lastNameField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid last name (letters only).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate username
        if (usernameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a username.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate password
        if (passwordField.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Please enter a password.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate phone number
        if (!isValidPhone(phoneField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid phone number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate email
        if (!isValidEmail(emailField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate address
        if (addressField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an address.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate city
        if (!isValidName(cityField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a valid city name (letters only).", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate postal code
        if (postalCodeField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a postal code.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate ailment selection
        if (ailmentComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select an ailment.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Validate date of birth selection
        Integer year = (Integer) yearComboBox.getSelectedItem();
               Integer month = (Integer) monthComboBox.getSelectedItem();
        Integer day = (Integer) dayComboBox.getSelectedItem();
        if (year == null || month == null || day == null) {
            JOptionPane.showMessageDialog(this, "Please select a valid date of birth.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private boolean isValidName(String name) {
        return name.matches("[a-zA-Z]+");
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("\\d{10}|(?:\\d{3}-){2}\\d{4}");
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
    }

    private void saveRegistrationData(String firstName, String lastName, String username, String password, String dob, String phone, String email, String address, String city, String postalCode, Ailment ailment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("person_data.csv", true))) {
            writer.write(String.join(",",
                    firstName,
                    lastName,
                    username,
                    password,
                    dob,
                    phone,
                    email,
                    address,
                    city,
                    postalCode,
                    ailment.getName(),
                    ailment.getDescription()));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving user data.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PersonInfo().setVisible(true));
    }
}


