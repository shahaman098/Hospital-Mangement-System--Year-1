package mynewgui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

public class ForgotPasswordDialog extends JDialog {
    private JTextField nameField, visitationNumberField;
    private JPasswordField newPasswordField;
    private JButton resetButton, cancelButton;

    public ForgotPasswordDialog(Frame parent) {
        super(parent, "Forgot Password", true);
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new GridBagLayout());
        setSize(400, 300);
        setLocationRelativeTo(null); // MIDDLE
        getContentPane().setBackground(new Color(240, 248, 255)); // Light blue 

        // Load logo image
        URL logoURL = getClass().getResource("/resources/logo.png");
        if (logoURL != null) {
            ImageIcon logoIcon = new ImageIcon(logoURL);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(logoLabel, new GridBagConstraints(0, 0, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 0, 10, 0), 0, 0));
        } else {
            System.err.println("Logo image not found.");
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        addLabelAndField("Name:", nameField = createTextField(), gbc, 1);
        addLabelAndField("Visitation Number:", visitationNumberField = createTextField(), gbc, 2);
        addLabelAndField("New Password:", newPasswordField = createPasswordField(), gbc, 3);

        resetButton = createButton("Reset Password");
        resetButton.addActionListener(this::resetPassword);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(resetButton, gbc);

        cancelButton = createButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        gbc.gridy = 5;
        add(cancelButton, gbc);
    }

    private void addLabelAndField(String labelText, Component field, GridBagConstraints gbc, int yPos) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(70, 130, 180));
        gbc.gridx = 0;
        gbc.gridy = yPos;
        add(label, gbc);
        gbc.gridx = 1;
        add(field, gbc);
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        textField.setBackground(Color.WHITE);
        return textField;
    }

    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 2));
        passwordField.setBackground(Color.WHITE);
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private void resetPassword(ActionEvent e) {
        String name = nameField.getText().trim();
        String visitationNumber = visitationNumberField.getText().trim();
        String newPassword = new String(newPasswordField.getPassword()).trim();

        if (name.isEmpty() || visitationNumber.isEmpty() || newPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("person_data.csv"))) {
            StringBuilder updatedData = new StringBuilder();
            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(name) && parts[13].equals(visitationNumber)) { // visitation number is at index 13
                    parts[3] = newPassword; // password is at index 3
                    found = true;
                }
                updatedData.append(String.join(",", parts)).append("\n");
            }

            if (!found) {
                JOptionPane.showMessageDialog(this, "Invalid name or visitation number.", "Reset Failed", JOptionPane.ERROR_MESSAGE);
            } else {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("person_data.csv"))) {
                    writer.write(updatedData.toString());
                    JOptionPane.showMessageDialog(this, "Password reset successfully.");
                    dispose();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error saving new password.", "File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading user data.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ForgotPasswordDialog(null).setVisible(true));
    }
}
