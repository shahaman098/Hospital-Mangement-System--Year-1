package DocRew;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Doctor {
    private String name;
    private String speciality;
    private double rating;
    private int totalReviews;
    private List<String> reviews;
    private static DoctorListScreen doctorListScreen;

    public Doctor(String name, String speciality, double rating, int totalReviews, List<String> reviews) {
        this.name = name;
        this.speciality = speciality;
        this.rating = rating;
        this.totalReviews = totalReviews;
        this.reviews = new ArrayList<>(reviews);
    }

    public String getName() {
        return name;
    }

    public String getSpeciality() {
        return speciality;
    }

    public double getRating() {
        return rating;
    }

    public int getTotalReviews() {
        return totalReviews;
    }

    public List<String> getReviews() {
        return reviews;
    }

    public void addReview(double newRating, String comment) {
        // Update rating calculation
        this.totalReviews++;
        this.rating = ((this.rating * (this.totalReviews - 1)) + newRating) / this.totalReviews;
        this.reviews.add(comment);
        // Save the updated doctor data to file
        saveDoctorData();
        // Notify DoctorListScreen to update the top-rated doctor
        if (doctorListScreen != null) {
            doctorListScreen.updateTopRatedDoctor();
        }
    }

    public static void setDoctorListScreen(DoctorListScreen screen) {
        doctorListScreen = screen;
    }

    public void saveDoctorData() {
        String tempFile = "doctors_temp.csv";
        String csvFile = "doctors.csv";
        String line;
        String csvSplitBy = ",";
        boolean doctorFound = false;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {
            String header = br.readLine(); // Read header
            bw.write(header); // Write header to temp file
            bw.newLine();
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(csvSplitBy);
                if (fields[0].equalsIgnoreCase(name)) {
                    doctorFound = true;
                    fields[2] = String.valueOf(rating);
                    fields[3] = String.valueOf(totalReviews);
                    bw.write(String.join(",", fields));
                    bw.newLine();
                    for (String review : reviews) {
                        bw.write(review);
                        bw.newLine();
                    }
                } else {
                    bw.write(line);
                    bw.newLine();
                }
            }
            if (!doctorFound) {
                bw.write(name + "," + speciality + "," + rating + "," + totalReviews);
                bw.newLine();
                for (String review : reviews) {
                    bw.write(review);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Replace old file with the updated file
        File oldFile = new File(csvFile);
        File newFile = new File(tempFile);
        if (oldFile.delete()) {
            newFile.renameTo(oldFile);
        }
    }

    public static List<Doctor> loadDoctorsFromFile() {
        List<Doctor> doctors = new ArrayList<>();
        String csvFile = "doctors.csv";
        String line;
        String csvSplitBy = ",";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            br.readLine(); // Skip the header
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(csvSplitBy);
                if (fields.length >= 4) {
                    String name = fields[0];
                    String speciality = fields[1];
                    double rating = Double.parseDouble(fields[2]);
                    int totalReviews = Integer.parseInt(fields[3]);
                    List<String> reviews = new ArrayList<>();
                    while ((line = br.readLine()) != null && !line.contains(",")) {
                        reviews.add(line);
                    }
                    doctors.add(new Doctor(name, speciality, rating, totalReviews, reviews));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return doctors;
    }
    
    public static Doctor findDoctorByName(String doctorName) {
        List<Doctor> doctors = loadDoctorsFromFile();
        for (Doctor doctor : doctors) {
            if (doctor.getName().equalsIgnoreCase(doctorName)) {
                return doctor;
            }
        }
        return null;
    }
}
