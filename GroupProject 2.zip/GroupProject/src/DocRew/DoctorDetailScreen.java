package DocRew;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DoctorDetailScreen extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtDoctorName;
    private JLabel lblRating;
    private JLabel lblTotalReviews;
    private JTextArea txtReviews;
    private Doctor currentDoctor;

    public DoctorDetailScreen() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(173, 216, 230)); // Set background color to light blue
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Doctor's name input field
        JLabel lblDoctorName = new JLabel("Enter Doctor Name:");
        lblDoctorName.setBounds(10, 10, 200, 20);
        contentPane.add(lblDoctorName);

        txtDoctorName = new JTextField();
        txtDoctorName.setBounds(220, 10, 200, 20);
        contentPane.add(txtDoctorName);

        // Search button
        JButton btnSearch = new JButton("Search");
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String doctorName = txtDoctorName.getText();
                currentDoctor = Doctor.findDoctorByName(doctorName);
                if (currentDoctor != null) {
                    refreshDoctorDetails();
                } else {
                    JOptionPane.showMessageDialog(null, "Doctor not found.");
                }
            }
        });
        btnSearch.setBounds(430, 10, 100, 20);
        contentPane.add(btnSearch);

        // Doctor's specialty
        JLabel lblSpeciality = new JLabel("Speciality: ");
        lblSpeciality.setBounds(10, 40, 760, 20);
        contentPane.add(lblSpeciality);

        // Doctor's rating
        lblRating = new JLabel("Rating: ");
        lblRating.setBounds(10, 70, 760, 20);
        contentPane.add(lblRating);

        // Total reviews
        lblTotalReviews = new JLabel("Total Reviews: ");
        lblTotalReviews.setBounds(10, 100, 760, 20);
        contentPane.add(lblTotalReviews);

        // Doctor's reviews
        JLabel lblReviews = new JLabel("Reviews:");
        lblReviews.setBounds(10, 130, 100, 20);
        contentPane.add(lblReviews);

        txtReviews = new JTextArea();
        txtReviews.setBounds(10, 160, 760, 300);
        txtReviews.setEditable(false);
        contentPane.add(txtReviews);

        // Back button to return to the doctor list screen
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DoctorListScreen doctorList = new DoctorListScreen();
                doctorList.setVisible(true);
                setVisible(false);
            }
        });
        btnBack.setBounds(350, 500, 100, 50);
        contentPane.add(btnBack);
    }

    private String getFormattedReviews(java.util.List<String> reviews) {
        StringBuilder sb = new StringBuilder();
        for (String review : reviews) {
            sb.append(review).append("\n");
        }
        return sb.toString();
    }

    public void refreshDoctorDetails() {
        if (currentDoctor != null) {
            lblRating.setText("Rating: " + String.format("%.1f", currentDoctor.getRating()));
            lblTotalReviews.setText("Total Reviews: " + currentDoctor.getTotalReviews());
            txtReviews.setText(getFormattedReviews(currentDoctor.getReviews()));
        }
    }

    public static void main(String[] args) {
        DoctorDetailScreen frame = new DoctorDetailScreen();
        frame.setVisible(true);
    }
}

