package DocRew;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class MainMenu extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblTopRatedDoctor;

    public MainMenu() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(173, 216, 230));  // Set background color to light blue
        setContentPane(contentPane);
        contentPane.setLayout(null);
        // Create and add the label to show the top-rated doctor
        lblTopRatedDoctor = new JLabel("Top Rated Doctor: Loading...");
        lblTopRatedDoctor.setBounds(10, 10, 760, 20);
        contentPane.add(lblTopRatedDoctor);
        // Create and add buttons
        JButton btnDoctorList = new JButton("Doctor List");
        btnDoctorList.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DoctorListScreen doctorListScreen = new DoctorListScreen();
                doctorListScreen.setVisible(true);
                setVisible(false);
            }
        });
        btnDoctorList.setBounds(325, 100, 150, 50);
        contentPane.add(btnDoctorList);
        JButton btnDoctorDetail = new JButton("Doctor Detail");
        btnDoctorDetail.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DoctorDetailScreen detailScreen = new DoctorDetailScreen();
                detailScreen.setVisible(true);
                setVisible(false);
            }
        });
        btnDoctorDetail.setBounds(325, 200, 150, 50);
        contentPane.add(btnDoctorDetail);
        JButton btnSubmitReview = new JButton("Submit Review");
        btnSubmitReview.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SubmitReviewScreen reviewScreen = new SubmitReviewScreen();
                reviewScreen.setVisible(true);
                setVisible(false);
            }
        });
        btnSubmitReview.setBounds(325, 300, 150, 50);
        contentPane.add(btnSubmitReview);
        // Initial update of the top-rated doctor label
        updateTopRatedDoctorLabel();
    }

    public void updateTopRatedDoctorLabel() {
        DoctorListScreen doctorListScreen = new DoctorListScreen();
        Doctor topRatedDoctor = doctorListScreen.getTopRatedDoctor();
        if (topRatedDoctor != null) {
            lblTopRatedDoctor.setText("Top Rated Doctor: " + topRatedDoctor.getName() + " (Rating: " + topRatedDoctor.getRating() + ")");
        } else {
            lblTopRatedDoctor.setText("Top Rated Doctor: None available");
        }
    }

    public static void main(String[] args) {
        MainMenu frame = new MainMenu();
        frame.setVisible(true);
    }
}

