package DocRew;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Comparator;
import java.util.List;

public class DoctorListScreen extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private List<Doctor> doctors;

    public DoctorListScreen() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(173, 216, 230));  // Set background color to light blue
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 10, 760, 450);
        contentPane.add(scrollPane);
        table = new JTable();
        scrollPane.setViewportView(table);
        // Load doctor data
        doctors = Doctor.loadDoctorsFromFile();
        // Table to display doctors
        String[] columnNames = {"Name", "Speciality", "Rating", "Total Reviews"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (Doctor doctor : doctors) {
            Object[] row = {doctor.getName(), doctor.getSpeciality(), doctor.getRating(), doctor.getTotalReviews()};
            model.addRow(row);
        }
        table.setModel(model);
        // Back button to return to the main menu
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainMenu mainMenu = new MainMenu();
                mainMenu.setVisible(true);
                setVisible(false);
            }
        });
        btnBack.setBounds(350, 470, 100, 50);
        contentPane.add(btnBack);
        // Add mouse listener for row double-click
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = table.getSelectedRow();
                    if (row != -1) {
                        Doctor selectedDoctor = doctors.get(row);
                        DoctorDetailScreen detailScreen = new DoctorDetailScreen();
                        detailScreen.setVisible(true);
                        setVisible(false);
                    }
                }
            }
        });
        // Set this screen as the current DoctorListScreen in Doctor class
        Doctor.setDoctorListScreen(this);
    }

    public Doctor getTopRatedDoctor() {
        return doctors.stream().max(Comparator.comparingDouble(Doctor::getRating)).orElse(null);
    }

    public void updateTopRatedDoctor() {
        // This method is called when a review is added
        // Update the table model to reflect the new top-rated doctor
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear existing rows
        // Re-load doctor data and add to the table
        doctors = Doctor.loadDoctorsFromFile();
        for (Doctor doctor : doctors) {
            Object[] row = {doctor.getName(), doctor.getSpeciality(), doctor.getRating(), doctor.getTotalReviews()};
            model.addRow(row);
        }
        // Optionally update top-rated doctor label in MainMenu
        MainMenu mainMenu = (MainMenu) JFrame.getFrames()[0];
        Doctor topRatedDoctor = getTopRatedDoctor();
        if (topRatedDoctor != null) {
            mainMenu.updateTopRatedDoctorLabel();
        }
    }

    public static void main(String[] args) {
        DoctorListScreen frame = new DoctorListScreen();
        frame.setVisible(true);
    }
}
