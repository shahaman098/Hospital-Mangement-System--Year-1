package DocRew;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SubmitReviewScreen extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtDoctorName;
    private JTextField txtRating;
    private JTextArea txtComments;

    public SubmitReviewScreen() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(173, 216, 230));  // Set background color to light blue
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblTitle = new JLabel("Submit Review");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblTitle.setBounds(300, 30, 200, 40);
        contentPane.add(lblTitle);
        JLabel lblDoctorName = new JLabel("Doctor Name:");
        lblDoctorName.setBounds(150, 100, 100, 30);
        contentPane.add(lblDoctorName);
        txtDoctorName = new JTextField();
        txtDoctorName.setBounds(300, 100, 200, 30);
        contentPane.add(txtDoctorName);
        txtDoctorName.setColumns(10);
        JLabel lblRating = new JLabel("Rating (0-5):");
        lblRating.setBounds(150, 150, 100, 30);
        contentPane.add(lblRating);
        txtRating = new JTextField();
        txtRating.setBounds(300, 150, 200, 30);
        contentPane.add(txtRating);
        txtRating.setColumns(10);
        JLabel lblComments = new JLabel("Comments:");
        lblComments.setBounds(150, 200, 100, 30);
        contentPane.add(lblComments);
        txtComments = new JTextArea();
        txtComments.setBounds(300, 200, 200, 100);
        contentPane.add(txtComments);
        JButton btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String doctorName = txtDoctorName.getText();
                String ratingStr = txtRating.getText();
                String comments = txtComments.getText();
                try {
                    double rating = Double.parseDouble(ratingStr);
                    if (rating < 0 || rating > 5) {
                        JOptionPane.showMessageDialog(null, "Please enter a rating between 0 and 5.");
                        return;
                    }
                    Doctor doctor = Doctor.findDoctorByName(doctorName);
                    if (doctor != null) {
                        doctor.addReview(rating, comments);
                        JOptionPane.showMessageDialog(null, "Review submitted successfully.");
                        DoctorListScreen doctorListScreen = new DoctorListScreen();
                        doctorListScreen.setVisible(true);
                        setVisible(false);
                    } else {
                        JOptionPane.showMessageDialog(null, "Doctor not found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid rating.");
                }
            }
        });
        btnSubmit.setBounds(300, 350, 100, 40);
        contentPane.add(btnSubmit);
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainMenu mainMenu = new MainMenu();
                mainMenu.setVisible(true);
                setVisible(false);
            }
        });
        btnBack.setBounds(450, 350, 100, 40);
        contentPane.add(btnBack);
    }
}

