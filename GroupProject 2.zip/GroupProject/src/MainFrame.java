import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class MainFrame extends JFrame {
    public MainFrame() {
        // Set up the frame
        setTitle("Main Application");
        setSize(1024, 768); // Increased height for better layout
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set the correct close operation
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top panel for navigation buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.setBackground(new Color(0x0A2472));

        // Create navigation buttons
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        navPanel.setBackground(new Color(0x0A2472));
        String[] buttonLabels = {"Finances", "Restaurant", "Doctor Review", "Patient Information"};
        for (String label : buttonLabels) {
            JButton button = createNavButton(label);
            navPanel.add(button);
        }
        topPanel.add(navPanel, BorderLayout.CENTER);

        // Add top panel to frame
        add(topPanel, BorderLayout.NORTH);

        // Center panel for logo, welcome, and description texts
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.setBackground(new Color(0x0A2472));

        // Add vertical glue before the content to push it down
        centerPanel.add(Box.createVerticalGlue());

        // Load and set the Brunel logo
        try {
            BufferedImage brunelLogo = ImageIO.read(new File("images/bul.png"));
            Image scaledBrunelLogo = brunelLogo.getScaledInstance(432, 230, Image.SCALE_SMOOTH); // Original size
            ImageIcon logoIcon = new ImageIcon(scaledBrunelLogo);
            JLabel logoLabel = new JLabel(logoIcon);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            centerPanel.add(logoLabel);
        } catch (IOException e) {
            e.printStackTrace();
        }

        centerPanel.add(Box.createVerticalStrut(20)); // Spacer between logo and welcome text

        JLabel welcomeLabel = new JLabel("Welcome to the Hospital Management System", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Montserrat", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(welcomeLabel);

        centerPanel.add(Box.createVerticalStrut(10)); // Spacer between welcome text and description

        JLabel descriptionLabel = new JLabel("<html><center>Loved for its power and simplicity, yet trusted to<br>secure the most confidential of data.</center></html>", JLabel.CENTER);
        descriptionLabel.setFont(new Font("Montserrat", Font.PLAIN, 18));
        descriptionLabel.setForeground(Color.WHITE);
        descriptionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(descriptionLabel);

        centerPanel.add(Box.createVerticalStrut(20)); // Spacer between description and copyright text

        JLabel copyrightLabel = new JLabel("© Brunel University London 2024", JLabel.CENTER);
        copyrightLabel.setFont(new Font("Montserrat", Font.PLAIN, 14));
        copyrightLabel.setForeground(Color.WHITE);
        copyrightLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(copyrightLabel);

        // Add vertical glue after the content to push it up from the bottom
        centerPanel.add(Box.createVerticalGlue());

        // Add center panel to frame
        add(centerPanel, BorderLayout.CENTER);
    }

    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Montserrat", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBackground(new Color(0x0A2472)); // Set background color to match the panel
        button.setOpaque(true);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Adjust padding

        // Add action listeners to navigation buttons
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (text) {
                    case "Finances":
                        try {
                            implementation.MainApplication.main(new String[]{});
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case "Restaurant":
                        try {
                            restaurantpackage.LoginFrame.main(new String[]{});
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case "Doctor Review":
                        try {
                            DocRew.MainMenu.main(new String[]{});
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case "Patient Information":
                        try {
                            mynewgui.LoginScreen.main(new String[]{});
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        break;
                }
            }
        });

        return button;
    }

    public static void main(String[] args) {
        // Create and display the frame
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }
}
