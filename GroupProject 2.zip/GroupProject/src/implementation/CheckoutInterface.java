package implementation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class CheckoutInterface extends JFrame {
    public JTextField searchField;
    public JTable patientTable;
    public DefaultTableModel patientTableModel;
    public JList<String> itemList;
    public DefaultListModel<String> itemListModel;
    public JLabel totalLabel;
    private List<BasketItem> basketItems;
    private JButton addButton, removeButton, checkoutButton;
    public JRadioButton treatmentsButton;
	private JRadioButton medicationsButton;
	private JRadioButton foodButton;
    private ButtonGroup itemGroup;
    private JPanel itemPanel;

    public CheckoutInterface(List<BasketItem> basketItems) {
        this.basketItems = basketItems;
        initUI();
        loadCSVData("src/implementation/treatments.csv"); // Ensure this path is correct
        populateItemList();
        calculateTotal();
    }

    private void initUI() {
        setTitle("Checkout");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        searchField = new JTextField(20);
        searchField.addActionListener(e -> searchPatient());

        patientTableModel = new DefaultTableModel(new String[]{"Patient Name", "Treatments", "Medications", "Food"}, 0);
        patientTable = new JTable(patientTableModel);
        JScrollPane patientScrollPane = new JScrollPane(patientTable);

        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        JScrollPane itemScrollPane = new JScrollPane(itemList);

        treatmentsButton = new JRadioButton("Treatments");
        medicationsButton = new JRadioButton("Medications");
        foodButton = new JRadioButton("Food");
        itemGroup = new ButtonGroup();
        itemGroup.add(treatmentsButton);
        itemGroup.add(medicationsButton);
        itemGroup.add(foodButton);

        itemPanel = new JPanel();
        itemPanel.setLayout(new GridLayout(3, 1));
        itemPanel.add(treatmentsButton);
        itemPanel.add(medicationsButton);
        itemPanel.add(foodButton);

        addButton = new JButton("Add Item");
        addButton.addActionListener(e -> addItem());

        removeButton = new JButton("Remove Item");
        removeButton.addActionListener(e -> removeItem());

        checkoutButton = new JButton("Checkout");
        checkoutButton.addActionListener(e -> performCheckout());

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        controlPanel.add(addButton);
        controlPanel.add(removeButton);
        controlPanel.add(checkoutButton);

        totalLabel = new JLabel("Total: $0.00");

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(controlPanel, BorderLayout.CENTER);
        bottomPanel.add(totalLabel, BorderLayout.SOUTH);

        add(searchField, BorderLayout.NORTH);
        add(patientScrollPane, BorderLayout.WEST);
        add(itemPanel, BorderLayout.CENTER);
        add(itemScrollPane, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void loadCSVData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                patientTableModel.addRow(data);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to load data from " + filePath + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void searchPatient() {
        String searchText = searchField.getText().toLowerCase();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(patientTableModel);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
        patientTable.setRowSorter(sorter);
    }

    public void addItem() {
        int selectedRow = patientTable.getSelectedRow();
        if (selectedRow >= 0) {
            String selectedType = "";
            if (treatmentsButton.isSelected()) selectedType = "Treatments";
            else if (medicationsButton.isSelected()) selectedType = "Medications";
            else if (foodButton.isSelected()) selectedType = "Food";

            int columnIndex = selectedType.equals("Treatments") ? 1 : selectedType.equals("Medications") ? 2 : 3;
            String selectedItem = (String) patientTable.getValueAt(selectedRow, columnIndex);

            if (selectedItem != null && !selectedItem.isEmpty()) {
                String[] items = selectedItem.split(";");
                for (String item : items) {
                    itemListModel.addElement(item.trim());
                }
                calculateTotal();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a patient first.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void removeItem() {
        int selectedIndex = itemList.getSelectedIndex();
        if (selectedIndex >= 0) {
            itemListModel.remove(selectedIndex);
            calculateTotal();
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to remove.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void calculateTotal() {
        double total = 0;
        for (int i = 0; i < itemListModel.getSize(); i++) {
            String item = itemListModel.getElementAt(i);
            String[] parts = item.split("\\(");
            if (parts.length > 1) {
                String pricePart = parts[1].replace(")", "").trim();
                try {
                    total += Double.parseDouble(pricePart);
                } catch (NumberFormatException e) {
                    // Ignore invalid number format
                }
            }
        }
        totalLabel.setText("Total: $" + String.format("%.2f", total));
    }

    public void performCheckout() {
        JOptionPane.showMessageDialog(this, "Checkout complete. Total amount: " + totalLabel.getText(), "Checkout", JOptionPane.INFORMATION_MESSAGE);
        itemListModel.clear();
        calculateTotal();
    }

    public void populateItemList() {
        for (BasketItem item : basketItems) {
            itemListModel.addElement(item.getItemName() + " (" + item.getAmount() + ")");
        }
    }

    public static class BasketItem {
        private String itemName;
        private String category;
        private String amount;

        public BasketItem(String itemName, String category, String amount) {
            this.itemName = itemName;
            this.category = category;
            this.amount = amount;
        }

        public String getItemName() {
            return itemName;
        }

        public String getCategory() {
            return category;
        }

        public String getAmount() {
            return amount;
        }
    }
}
