package implementation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NewInvoiceInterface extends JFrame {
    public JTextField patientNameField;
    public JTextField treatmentsField;
    public JTextField medicationField;
    public JTextField foodField;
    public JButton generateInvoiceButton;
    private JButton saveInvoiceButton;
    private JButton brunelLogoButton;
    private JLabel totalCostLabel;
    private List<Invoice> invoiceList;
    public DefaultTableModel invoiceTableModel;

    private JButton checkoutButton, basketButton, newInvoiceButton; // Nav bar buttons

    public NewInvoiceInterface() {
        invoiceList = new ArrayList<>();
        createInvoiceInterface();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
    }

    private void createInvoiceInterface() {
        setTitle("Invoice Management System");
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        addInputComponents(inputPanel);

        JPanel invoicePanel = createInvoicePanel();
        setupNavigationBar();

        add(inputPanel, BorderLayout.NORTH);
        add(invoicePanel, BorderLayout.CENTER);
    }

    private void addInputComponents(JPanel inputPanel) {
        inputPanel.add(new JLabel("Patient Name:"));
        patientNameField = new JTextField();
        inputPanel.add(patientNameField);
        inputPanel.add(new JLabel("Treatments:"));
        treatmentsField = new JTextField();
        inputPanel.add(treatmentsField);
        inputPanel.add(new JLabel("Medication:"));
        medicationField = new JTextField();
        inputPanel.add(medicationField);
        inputPanel.add(new JLabel("Food:"));
        foodField = new JTextField();
        inputPanel.add(foodField);

        setupButtons(inputPanel);
    }

    private void setupButtons(JPanel panel) {
        generateInvoiceButton = new JButton("Generate Invoice");
        generateInvoiceButton.addActionListener(this::generateInvoiceClicked);
        panel.add(new JLabel());
        panel.add(generateInvoiceButton);

        saveInvoiceButton = new JButton("Save Invoice");
        saveInvoiceButton.addActionListener(this::saveInvoiceClicked);
        panel.add(new JLabel());
        panel.add(saveInvoiceButton);
    }

    private JPanel createInvoicePanel() {
        JPanel invoicePanel = new JPanel(new BorderLayout());
        invoiceTableModel = new DefaultTableModel(new Object[]{"Date", "Patient Name", "Treatments", "Medication", "Food", "Total Cost"}, 0);
        JTable invoiceTable = new JTable(invoiceTableModel);
        JScrollPane scrollPane = new JScrollPane(invoiceTable);
        invoicePanel.add(new JLabel("Invoice History"), BorderLayout.NORTH);
        invoicePanel.add(scrollPane, BorderLayout.CENTER);
        return invoicePanel;
    }

    private void setupNavigationBar() {
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.add(Box.createVerticalGlue());

        checkoutButton = new JButton(new ImageIcon("images/wallet.png"));
        checkoutButton.setBorderPainted(false);
        checkoutButton.setContentAreaFilled(false);
        checkoutButton.addActionListener(e -> openCheckoutInterface());
        navPanel.add(checkoutButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        basketButton = new JButton(new ImageIcon("images/cart.png"));
        basketButton.setBorderPainted(false);
        basketButton.setContentAreaFilled(false);
        basketButton.addActionListener(e -> openBasketWindow());
        navPanel.add(basketButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        newInvoiceButton = new JButton(new ImageIcon("images/invoice_active.png"));
        newInvoiceButton.setBorderPainted(false);
        newInvoiceButton.setContentAreaFilled(false);
        newInvoiceButton.addActionListener(e -> openNewInvoiceInterface());
        navPanel.add(newInvoiceButton);
        navPanel.add(Box.createVerticalGlue());

        getContentPane().add(navPanel, BorderLayout.EAST);
    }

    public void generateInvoiceClicked(ActionEvent e) {
        String patientName = patientNameField.getText().trim();
        String treatments = treatmentsField.getText().trim();
        String medication = medicationField.getText().trim();
        String food = foodField.getText().trim();

        String[] treatmentsParts = treatments.split("\\s+", 2); 
        String treatmentsName = treatmentsParts[0];
        String treatmentsCost = treatmentsParts.length > 1 ? treatmentsParts[1] : "0.00";

        String[] medicationParts = medication.split("\\s+", 2); 
        String medicationName = medicationParts[0];
        String medicationCost = medicationParts.length > 1 ? medicationParts[1] : "0.00";

        String[] foodParts = food.split("\\s+", 2); 
        String foodName = foodParts[0];
        String foodCost = foodParts.length > 1 ? foodParts[1] : "0.00";

       
        String totalCost = "£100.00"; 

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = dateFormat.format(new Date());

        Invoice invoice = new Invoice(date, patientName, treatmentsName, medicationName, foodName, totalCost);

        invoiceList.add(invoice);

        addInvoiceToTable(invoice);
    }

    public void addInvoiceToTable(Invoice invoice) {
        invoiceTableModel.addRow(new Object[]{
                invoice.getDate(),
                invoice.getPatientName(),
                invoice.getTreatments(),
                invoice.getMedication(),
                invoice.getFood(),
                invoice.getTotalCost()
        });

        invoiceTableModel.fireTableDataChanged();
    }

    private void saveInvoiceClicked(ActionEvent e) {
        // Implement save functionality if needed
    }

    private void openCheckoutInterface() {
        CheckoutInterface checkoutInterface = new CheckoutInterface(new ArrayList<>()); 
        checkoutInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        checkoutInterface.setVisible(true);
    }

    private void openBasketWindow() {
        BasketWindow basketWindow = new BasketWindow(new ArrayList<>()); 
        basketWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        basketWindow.setVisible(true);
    }

    private void openNewInvoiceInterface() {
        NewInvoiceInterface newInvoiceInterface = new NewInvoiceInterface();
        newInvoiceInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        newInvoiceInterface.setVisible(true);
    }

    public static class Invoice {
        private String date, patientName, treatments, medication, food, totalCost;

        public Invoice(String date, String patientName, String treatments, String medication, String food, String totalCost) {
            this.date = date;
            this.patientName = patientName;
            this.treatments = treatments;
            this.medication = medication;
            this.food = food;
            this.totalCost = totalCost;
        }

        public String getDate() {
            return date;
        }

        public String getPatientName() {
            return patientName;
        }

        public String getTreatments() {
            return treatments;
        }

        public String getMedication() {
            return medication;
        }

        public String getFood() {
            return food;
        }

        public String getTotalCost() {
            return totalCost;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            NewInvoiceInterface invoiceInterface = new NewInvoiceInterface();
            invoiceInterface.setVisible(true);
        });
    }
}
