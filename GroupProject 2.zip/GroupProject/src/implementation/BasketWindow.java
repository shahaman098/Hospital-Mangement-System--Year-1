package implementation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class BasketWindow extends JFrame {
    public DefaultListModel<String> itemListModel;
    private JList<String> itemList;
    public JButton checkoutButton;
    private List<CheckoutInterface.BasketItem> basketItems;

    public BasketWindow(List<CheckoutInterface.BasketItem> basketItems) {
        this.basketItems = basketItems;
        initUI();
        populateItemList();
    }

    private void initUI() {
        setTitle("Basket");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        JScrollPane itemScrollPane = new JScrollPane(itemList);

        checkoutButton = new JButton("Checkout");
        checkoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCheckoutInterface();
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(checkoutButton);

        add(itemScrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void populateItemList() {
        for (CheckoutInterface.BasketItem item : basketItems) {
            itemListModel.addElement(item.getItemName() + " (" + item.getAmount() + ")");
        }
    }

    private void openCheckoutInterface() {
        CheckoutInterface checkoutInterface = new CheckoutInterface(basketItems);
        checkoutInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        checkoutInterface.setVisible(true);
        dispose();
    }
}