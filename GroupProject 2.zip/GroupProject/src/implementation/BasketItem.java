package implementation;

public class BasketItem {
    private String itemName;
    private String category;
    private String amount;

    public BasketItem(String itemName, String category, String amount) {
        this.itemName = itemName;
        this.category = category;
        this.amount = amount;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategory() {
        return category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
