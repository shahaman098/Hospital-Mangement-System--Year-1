package implementation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class MainApplication extends JFrame {
    public JTextField searchField;
    public JTable treatmentTable;
    public DefaultTableModel treatmentTableModel;
    private JButton filterButton, brunelLogoButton;
    public JButton checkoutButton;
    private JButton basketButton, addButton;
    public JButton newInvoiceButton;
    private JButton viewAllButton;
    private JButton detailedFinanceButton;
    private JPopupMenu filterMenu, financeMenu;
    public List<CheckoutInterface.BasketItem> basketItems;
    public Map<String, Map<String, Double>> yearlyData;
    private Map<String, Double> summaryData;
    private SimpleDateFormat dateFormat;
    private DecimalFormat decimalFormat;

    public MainApplication() {
        setTitle("Medical Store Application");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        // Initialize basketItems list
        basketItems = new ArrayList<>();
        yearlyData = new HashMap<>();
        summaryData = new HashMap<>();
        dateFormat = new SimpleDateFormat("dd/MM/yy");
        decimalFormat = new DecimalFormat("#.00");

        initComponents();
        setupLayout();
        loadCSVData("src/implementation/treatments.csv");
    }

    private void initComponents() {
        searchField = new JTextField(20);

        filterButton = new JButton(new ImageIcon("images/filterImage.png"));
        filterButton.setBorderPainted(false);
        filterButton.setContentAreaFilled(false);
        filterMenu = new JPopupMenu();
        JMenuItem filterByNameAsc = new JMenuItem("Filter by Name (Asc)");
        JMenuItem filterByNameDesc = new JMenuItem("Filter by Name (Desc)");
        filterMenu.add(filterByNameAsc);
        filterMenu.add(filterByNameDesc);

        filterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                filterMenu.show(filterButton, filterButton.getWidth() / 2, filterButton.getHeight() / 2);
            }
        });

        filterByNameAsc.addActionListener(e -> filterTableByName(true));
        filterByNameDesc.addActionListener(e -> filterTableByName(false));

        brunelLogoButton = new JButton(new ImageIcon(""));
        brunelLogoButton.setBorderPainted(false);
        brunelLogoButton.setContentAreaFilled(false);

        treatmentTableModel = new DefaultTableModel(new String[]{"Patient Name", "Year", "Treatments", "Medications", "Foods"}, 0);
        treatmentTable = new JTable(treatmentTableModel);

        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                String text = searchField.getText().toLowerCase();
                filterTable(treatmentTableModel, treatmentTable, text);
            }
        });

        checkoutButton = new JButton(new ImageIcon("images/wallet.png"));
        checkoutButton.setBorderPainted(false);
        checkoutButton.setContentAreaFilled(false);
        checkoutButton.addActionListener(e -> openCheckoutInterface());

        basketButton = new JButton(new ImageIcon("images/cart.png"));
        basketButton.setBorderPainted(false);
        basketButton.setContentAreaFilled(false);
        basketButton.addActionListener(e -> openBasketWindow());

        newInvoiceButton = new JButton(new ImageIcon("images/invoice.png"));
        newInvoiceButton.setBorderPainted(false);
        newInvoiceButton.setContentAreaFilled(false);
        newInvoiceButton.addActionListener(e -> openNewInvoiceInterface());

        viewAllButton = new JButton("View All");
        viewAllButton.addActionListener(e -> removeFilters());

        financeMenu = new JPopupMenu();
        JMenuItem summaryByYear = new JMenuItem("Summary by Year");
        JMenuItem summaryByTreatment = new JMenuItem("Summary for Treatment");
        JMenuItem summaryByFood = new JMenuItem("Summary for Food");
        JMenuItem summaryByMedication = new JMenuItem("Summary for Medication");

        financeMenu.add(summaryByYear);
        financeMenu.add(summaryByTreatment);
        financeMenu.add(summaryByFood);
        financeMenu.add(summaryByMedication);

        summaryByYear.addActionListener(e -> showSummaryByYear());
        summaryByTreatment.addActionListener(e -> showSummary("Treatments"));
        summaryByFood.addActionListener(e -> showSummary("Foods"));
        summaryByMedication.addActionListener(e -> showSummary("Medications"));

        addButton = new JButton("Add to Basket");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addToBasket();
            }
        });
    }

    private void setupLayout() {
        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(brunelLogoButton, BorderLayout.NORTH);

        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.add(Box.createVerticalGlue());
        navPanel.add(checkoutButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(basketButton);
        navPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        navPanel.add(newInvoiceButton);
        navPanel.add(Box.createVerticalGlue());

        rightPanel.add(navPanel, BorderLayout.CENTER);

        contentPane.add(rightPanel, BorderLayout.EAST);

        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel topLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topLeftPanel.add(filterButton);
        topPanel.add(topLeftPanel, BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);

        contentPane.add(topPanel, BorderLayout.NORTH);

        JScrollPane treatmentScrollPane = new JScrollPane(treatmentTable);
        contentPane.add(treatmentScrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(viewAllButton, BorderLayout.EAST);
        bottomPanel.add(addButton, BorderLayout.CENTER);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);

        detailedFinanceButton = new JButton("Detailed Finance Results");
        bottomPanel.add(detailedFinanceButton, BorderLayout.WEST);

        detailedFinanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                financeMenu.show(detailedFinanceButton, detailedFinanceButton.getWidth() / 2, detailedFinanceButton.getHeight() / 2);
            }
        });
    }

    public void loadCSVData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String patientName = data[0].trim();
                String year = extractYearFromDate(data[4].trim());
                double treatments = parsePrice(data[1]);
                double medications = parsePrice(data[2]);
                double foods = parsePrice(data[3]);

                treatmentTableModel.addRow(new Object[]{patientName, year, data[1], data[2], data[3]});

                yearlyData.computeIfAbsent(year, k -> new HashMap<>());
                yearlyData.get(year).merge("Treatments", treatments, Double::sum);
                yearlyData.get(year).merge("Medications", medications, Double::sum);
                yearlyData.get(year).merge("Foods", foods, Double::sum);

                summaryData.merge("Treatments", treatments, Double::sum);
                summaryData.merge("Medications", medications, Double::sum);
                summaryData.merge("Foods", foods, Double::sum);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to load data from " + filePath + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public String extractYearFromDate(String date) {
        try {
            return new SimpleDateFormat("yyyy").format(dateFormat.parse(date));
        } catch (ParseException e) {
            return "Unknown";
        }
    }

    public double parsePrice(String items) {
        double total = 0;
        if (items != null && !items.isEmpty()) {
            String[] itemArray = items.split(";");
            for (String item : itemArray) {
                String[] parts = item.split("\\(");
                if (parts.length == 2) {
                    try {
                        total += Double.parseDouble(parts[1].replace(")", "").trim());
                    } catch (NumberFormatException e) {
                        // Ignore invalid number format
                    }
                }
            }
        }
        return total;
    }

    public void filterTable(DefaultTableModel model, JTable table, String text) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
        table.setRowSorter(sorter);
    }

    public void filterTableByName(boolean ascending) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(treatmentTableModel);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
        sortKeys.add(new RowSorter.SortKey(0, ascending ? SortOrder.ASCENDING : SortOrder.DESCENDING));
        sorter.setSortKeys(sortKeys);
        treatmentTable.setRowSorter(sorter);
    }

    private void removeFilters() {
        treatmentTable.setRowSorter(null);
    }

    public void addToBasket() {
        int selectedRow = treatmentTable.getSelectedRow();
        if (selectedRow != -1) {
            String patientName = treatmentTable.getValueAt(selectedRow, 0).toString();
            String treatments = treatmentTable.getValueAt(selectedRow, 2).toString();
            String medications = treatmentTable.getValueAt(selectedRow, 3).toString();
            String foods = treatmentTable.getValueAt(selectedRow, 4).toString();
            basketItems.add(new CheckoutInterface.BasketItem(patientName, treatments, medications));
        }
    }

    private void openCheckoutInterface() {
        CheckoutInterface checkoutInterface = new CheckoutInterface(basketItems);
        checkoutInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        checkoutInterface.setVisible(true);
    }

    private void openBasketWindow() {
        BasketWindow basketWindow = new BasketWindow(basketItems);
        basketWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        basketWindow.setVisible(true);
    }

    private void openNewInvoiceInterface() {
        NewInvoiceInterface newInvoiceInterface = new NewInvoiceInterface();
        newInvoiceInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        newInvoiceInterface.setVisible(true);
    }

    public void showSummaryByYear() {
        StringBuilder message = new StringBuilder();
        List<String> sortedYears = new ArrayList<>(yearlyData.keySet());
        Collections.sort(sortedYears);

        for (String year : sortedYears) {
            message.append("Year: ").append(year).append("\n");
            Map<String, Double> data = yearlyData.get(year);
            for (String category : data.keySet()) {
                if (category.equals("Foods")) {
                    message.append(category).append(": ").append(decimalFormat.format(data.get(category))).append("\n");
                } else {
                    message.append(category).append(": ").append(data.get(category)).append("\n");
                }
            }
            message.append("\n");
        }
        JOptionPane.showMessageDialog(this, message.toString(), "Summary by Year", JOptionPane.INFORMATION_MESSAGE);
    }

    public void showSummary(String category) {
        StringBuilder message = new StringBuilder();
        message.append(category).append(" Summary:\n\n");
        List<String> sortedYears = new ArrayList<>(yearlyData.keySet());
        Collections.sort(sortedYears);

        for (String year : sortedYears) {
            Double amount = yearlyData.get(year).get(category);
            if (amount != null) {
                if (category.equals("Foods")) {
                    message.append(year).append(": ").append(decimalFormat.format(amount)).append("\n");
                } else {
                    message.append(year).append(": ").append(amount).append("\n");
                }
            }
        }
        JOptionPane.showMessageDialog(this, message.toString(), category + " Summary", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainApplication frame = new MainApplication();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
