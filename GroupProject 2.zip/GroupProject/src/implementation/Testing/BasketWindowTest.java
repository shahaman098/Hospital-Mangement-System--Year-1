package implementation.Testing;

import implementation.BasketWindow;
import implementation.CheckoutInterface;
import implementation.CheckoutInterface.BasketItem;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;

import java.awt.Window;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class BasketWindowTest {

    private BasketWindow basketWindow;
    private List<BasketItem> basketItems;

    @Before
    public void setUp() {
        basketItems = new ArrayList<>();
        basketItems.add(new BasketItem("Item1", "Treatments", "10.00"));
        basketItems.add(new BasketItem("Item2", "Medications", "20.50"));
        basketItems.add(new BasketItem("Item3", "Food", "30.75"));
        basketWindow = new BasketWindow(basketItems);
    }

    @Test
    public void testPopulateItemList() {
        DefaultListModel<String> model = basketWindow.itemListModel;
        assertNotNull(model);
        assertEquals(3, model.getSize());
        assertEquals("Item1 (10.00)", model.getElementAt(0));
        assertEquals("Item2 (20.50)", model.getElementAt(1));
        assertEquals("Item3 (30.75)", model.getElementAt(2));
    }

    @Test
    public void testOpenCheckoutInterface() {
        basketWindow.checkoutButton.doClick(); // Simulate button click

        // Verify that the BasketWindow is closed
        assertFalse(basketWindow.isVisible());

        // Verify that the CheckoutInterface is opened
        boolean checkoutInterfaceOpened = false;
        for (Window window : Window.getWindows()) {
            if (window instanceof CheckoutInterface) {
                checkoutInterfaceOpened = true;
                break;
            }
        }
        assertTrue(checkoutInterfaceOpened);
    }
}
