package implementation.Testing;

import implementation.NewInvoiceInterface;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;

import static org.junit.Assert.*;

public class NewInvoiceInterfaceTest {

    private NewInvoiceInterface newInvoiceInterface;

    @Before
    public void setUp() {
        newInvoiceInterface = new NewInvoiceInterface();
    }

    @Test
    public void testGenerateInvoice() {
        // Set input values
        newInvoiceInterface.patientNameField.setText("John Doe");
        newInvoiceInterface.treatmentsField.setText("TreatmentA 100.00");
        newInvoiceInterface.medicationField.setText("MedicationB 50.00");
        newInvoiceInterface.foodField.setText("FoodC 30.00");

        // Simulate button click to generate invoice
        newInvoiceInterface.generateInvoiceButton.doClick();

        // Verify that the invoice is added to the table
        DefaultTableModel model = newInvoiceInterface.invoiceTableModel;
        assertEquals(1, model.getRowCount());
        assertEquals("John Doe", model.getValueAt(0, 1));
        assertEquals("TreatmentA", model.getValueAt(0, 2));
        assertEquals("MedicationB", model.getValueAt(0, 3));
        assertEquals("FoodC", model.getValueAt(0, 4));
        assertEquals("£100.00", model.getValueAt(0, 5)); // Adjust if needed
    }

    @Test
    public void testAddInvoiceToTable() {
        // Create a new invoice
        NewInvoiceInterface.Invoice invoice = new NewInvoiceInterface.Invoice(
                "2023-01-01 10:00:00",
                "Jane Doe",
                "TreatmentX",
                "MedicationY",
                "FoodZ",
                "£150.00"
        );

        // Add invoice to the table
        newInvoiceInterface.addInvoiceToTable(invoice);

        // Verify that the invoice is added to the table
        DefaultTableModel model = newInvoiceInterface.invoiceTableModel;
        assertEquals(1, model.getRowCount());
        assertEquals("2023-01-01 10:00:00", model.getValueAt(0, 0));
        assertEquals("Jane Doe", model.getValueAt(0, 1));
        assertEquals("TreatmentX", model.getValueAt(0, 2));
        assertEquals("MedicationY", model.getValueAt(0, 3));
        assertEquals("FoodZ", model.getValueAt(0, 4));
        assertEquals("£150.00", model.getValueAt(0, 5));
    }

    @Test
    public void testGenerateInvoiceClicked() {
        // Set input values
        newInvoiceInterface.patientNameField.setText("John Smith");
        newInvoiceInterface.treatmentsField.setText("TreatmentB 120.00");
        newInvoiceInterface.medicationField.setText("MedicationC 60.00");
        newInvoiceInterface.foodField.setText("FoodD 40.00");

        // Create a dummy action event
        ActionEvent e = new ActionEvent(newInvoiceInterface.generateInvoiceButton, ActionEvent.ACTION_PERFORMED, null);

        // Call the method directly
        newInvoiceInterface.generateInvoiceClicked(e);

        // Verify that the invoice is added to the table
        DefaultTableModel model = newInvoiceInterface.invoiceTableModel;
        assertEquals(1, model.getRowCount());
        assertEquals("John Smith", model.getValueAt(0, 1));
        assertEquals("TreatmentB", model.getValueAt(0, 2));
        assertEquals("MedicationC", model.getValueAt(0, 3));
        assertEquals("FoodD", model.getValueAt(0, 4));
        assertEquals("£100.00", model.getValueAt(0, 5)); // Adjust if needed
    }
}
