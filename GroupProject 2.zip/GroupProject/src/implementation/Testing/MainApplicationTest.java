package implementation.Testing;

import implementation.MainApplication;
import implementation.CheckoutInterface;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;

public class MainApplicationTest {

    private MainApplication mainApplication;

    @Before
    public void setUp() {
        mainApplication = new MainApplication();
    }

    @Test
    public void testExtractYearFromDate_validDate() throws ParseException {
        String date = "12/05/21";
        String expectedYear = "2021";
        String actualYear = mainApplication.extractYearFromDate(date);
        assertEquals(expectedYear, actualYear);
    }

    @Test
    public void testExtractYearFromDate_invalidDate() {
        String date = "invalid date";
        String expectedYear = "Unknown";
        String actualYear = mainApplication.extractYearFromDate(date);
        assertEquals(expectedYear, actualYear);
    }

    @Test
    public void testParsePrice_validItems() {
        String items = "Item1(10.00);Item2(20.50);Item3(30.75)";
        double expectedTotal = 61.25;
        double actualTotal = mainApplication.parsePrice(items);
        assertEquals(expectedTotal, actualTotal, 0.001);
    }

    @Test
    public void testParsePrice_invalidItems() {
        String items = "Item1(invalid);Item2(20.50);Item3()";
        double expectedTotal = 20.50;
        double actualTotal = mainApplication.parsePrice(items);
        assertEquals(expectedTotal, actualTotal, 0.001);
    }

    @Test
    public void testFilterTable() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Year", "Treatments", "Medications", "Foods"}, 0);
        model.addRow(new Object[]{"John Doe", "2021", "Treatment1(100.00)", "Medication1(50.00)", "Food1(10.00)"});
        model.addRow(new Object[]{"Jane Smith", "2020", "Treatment2(200.00)", "Medication2(75.00)", "Food2(20.00)"});
        mainApplication.treatmentTableModel = model;
        mainApplication.treatmentTable = new JTable(model);

        mainApplication.filterTable(model, mainApplication.treatmentTable, "John");

        assertEquals(1, mainApplication.treatmentTable.getRowCount());
        assertEquals("John Doe", mainApplication.treatmentTable.getValueAt(0, 0));
    }

    @Test
    public void testFilterTableByName_ascending() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Year", "Treatments", "Medications", "Foods"}, 0);
        model.addRow(new Object[]{"John Doe", "2021", "Treatment1(100.00)", "Medication1(50.00)", "Food1(10.00)"});
        model.addRow(new Object[]{"Jane Smith", "2020", "Treatment2(200.00)", "Medication2(75.00)", "Food2(20.00)"});
        mainApplication.treatmentTableModel = model;
        mainApplication.treatmentTable = new JTable(model);

        mainApplication.filterTableByName(true);

        assertEquals("Jane Smith", mainApplication.treatmentTable.getValueAt(0, 0));
        assertEquals("John Doe", mainApplication.treatmentTable.getValueAt(1, 0));
    }

    @Test
    public void testFilterTableByName_descending() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Year", "Treatments", "Medications", "Foods"}, 0);
        model.addRow(new Object[]{"John Doe", "2021", "Treatment1(100.00)", "Medication1(50.00)", "Food1(10.00)"});
        model.addRow(new Object[]{"Jane Smith", "2020", "Treatment2(200.00)", "Medication2(75.00)", "Food2(20.00)"});
        mainApplication.treatmentTableModel = model;
        mainApplication.treatmentTable = new JTable(model);

        mainApplication.filterTableByName(false);

        assertEquals("John Doe", mainApplication.treatmentTable.getValueAt(0, 0));
        assertEquals("Jane Smith", mainApplication.treatmentTable.getValueAt(1, 0));
    }

    @Test
    public void testAddToBasket() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Year", "Treatments", "Medications", "Foods"}, 0);
        model.addRow(new Object[]{"John Doe", "2021", "Treatment1(100.00)", "Medication1(50.00)", "Food1(10.00)"});
        mainApplication.treatmentTableModel = model;
        mainApplication.treatmentTable = new JTable(model);

        mainApplication.treatmentTable.setRowSelectionInterval(0, 0);
        mainApplication.addToBasket();

        List<CheckoutInterface.BasketItem> basketItems = mainApplication.basketItems;
        assertEquals(1, basketItems.size());
        assertEquals("John Doe", basketItems.get(0).getItemName());
    }

}
