package implementation.Testing;

import implementation.CheckoutInterface;
import implementation.CheckoutInterface.BasketItem;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class CheckoutInterfaceTest {

    private CheckoutInterface checkoutInterface;

    @Before
    public void setUp() {
        List<BasketItem> basketItems = new ArrayList<>();
        basketItems.add(new BasketItem("Item1", "Treatments", "10.00"));
        basketItems.add(new BasketItem("Item2", "Medications", "20.50"));
        basketItems.add(new BasketItem("Item3", "Food", "30.75"));
        checkoutInterface = new CheckoutInterface(basketItems);
        checkoutInterface.itemListModel.clear(); // Clear the initial list to ensure a clean state
    }

    @Test
    public void testLoadCSVData() {
        DefaultTableModel model = checkoutInterface.patientTableModel;
        assertNotNull(model);
        assertEquals(96, model.getRowCount()); // Adjusted based on actual CSV data
    }

    @Test
    public void testSearchPatient() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Treatments", "Medications", "Food"}, 0);
        model.addRow(new Object[]{"John Doe", "Treatment1(100.00)", "Medication1(50.00)", "Food1(10.00)"});
        model.addRow(new Object[]{"Jane Smith", "Treatment2(200.00)", "Medication2(75.00)", "Food2(20.00)"});
        checkoutInterface.patientTableModel = model;
        checkoutInterface.patientTable = new JTable(model);

        checkoutInterface.searchField.setText("John");
        checkoutInterface.searchPatient();

        assertEquals(1, checkoutInterface.patientTable.getRowCount());
        assertEquals("John Doe", checkoutInterface.patientTable.getValueAt(0, 0));
    }

    @Test
    public void testAddItem() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Treatments", "Medications", "Food"}, 0);
        model.addRow(new Object[]{"John Doe", "Treatment1(100.00);Treatment2(50.00)", "Medication1(50.00)", "Food1(10.00)"});
        checkoutInterface.patientTableModel = model;
        checkoutInterface.patientTable = new JTable(model);

        checkoutInterface.patientTable.setRowSelectionInterval(0, 0);
        checkoutInterface.treatmentsButton.setSelected(true);
        checkoutInterface.addItem();

        assertEquals(2, checkoutInterface.itemListModel.size());
        assertEquals("Treatment1(100.00)", checkoutInterface.itemListModel.getElementAt(0));
        assertEquals("Treatment2(50.00)", checkoutInterface.itemListModel.getElementAt(1));
    }

    @Test
    public void testRemoveItem() {
        checkoutInterface.itemListModel.addElement("Treatment1(100.00)");
        checkoutInterface.itemListModel.addElement("Medication1(50.00)");
        checkoutInterface.itemListModel.addElement("Food1(10.00)");
        checkoutInterface.itemList.setSelectedIndex(0);
        checkoutInterface.removeItem();

        assertEquals(2, checkoutInterface.itemListModel.size());
        assertFalse(checkoutInterface.itemListModel.contains("Treatment1(100.00)"));
    }

    @Test
    public void testCalculateTotal() {
        checkoutInterface.itemListModel.addElement("Treatment1(100.00)");
        checkoutInterface.itemListModel.addElement("Medication1(50.00)");
        checkoutInterface.itemListModel.addElement("Food1(10.00)");
        checkoutInterface.calculateTotal();

        assertEquals("Total: $160.00", checkoutInterface.totalLabel.getText());
    }

    @Test
    public void testPerformCheckout() {
        checkoutInterface.itemListModel.addElement("Treatment1(100.00)");
        checkoutInterface.itemListModel.addElement("Medication1(50.00)");
        checkoutInterface.itemListModel.addElement("Food1(10.00)");
        checkoutInterface.calculateTotal();

        // Simulate checkout
        checkoutInterface.performCheckout();

        assertEquals(0, checkoutInterface.itemListModel.size());
        assertEquals("Total: $0.00", checkoutInterface.totalLabel.getText());
    }

    @Test
    public void testPopulateItemList() {
        checkoutInterface.populateItemList();

        assertEquals(3, checkoutInterface.itemListModel.size());
        assertEquals("Item1 (10.00)", checkoutInterface.itemListModel.getElementAt(0));
        assertEquals("Item2 (20.50)", checkoutInterface.itemListModel.getElementAt(1));
        assertEquals("Item3 (30.75)", checkoutInterface.itemListModel.getElementAt(2));
    }
}
