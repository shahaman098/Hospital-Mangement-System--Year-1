package restaurantpackage;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalRestaurantManagementSystem extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField nameField, descField, priceField;
    private List<FoodItem> foodItems;
    private List<FoodItem> basketItems;

    public HospitalRestaurantManagementSystem() {
        // Initialize lists
        foodItems = new ArrayList<>();
        basketItems = new ArrayList<>();
        loadCSV("foods - Copy.csv"); 

        // Frame settings
        setTitle("Hospital Restaurant Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout settings
        getContentPane().setLayout(new BorderLayout());

        // Table settings
        model = new DefaultTableModel(new String[]{"Name", "Description", "Price"}, 0);
        table = new JTable(model);
        loadTableData();
        getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

        // Panel for form inputs
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(5, 2));
        formPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        formPanel.add(nameField);
        formPanel.add(new JLabel("Description:"));
        descField = new JTextField();
        formPanel.add(descField);
        formPanel.add(new JLabel("Price:"));
        priceField = new JTextField();
        formPanel.add(priceField);
        JButton addButton = new JButton("Add Food Item");
        addButton.addActionListener(new AddButtonListener());
        formPanel.add(addButton);
        JButton deleteButton = new JButton("Delete Selected Item");
        deleteButton.addActionListener(new DeleteButtonListener());
        formPanel.add(deleteButton);
        JButton addToBasketButton = new JButton("Add to Basket");
        addToBasketButton.addActionListener(new AddToBasketListener());
        formPanel.add(addToBasketButton);
        JButton viewBasketButton = new JButton("View Basket");
        viewBasketButton.addActionListener(new ViewBasketListener());
        formPanel.add(viewBasketButton);
        getContentPane().add(formPanel, BorderLayout.SOUTH);
    }

    private void loadCSV(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the header line
                }
                String[] values = line.split(",");
                foodItems.add(new FoodItem(values[0], values[1], Double.parseDouble(values[2])));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTableData() {
        for (FoodItem item : foodItems) {
            model.addRow(new Object[]{item.getName(), item.getDescription(), item.getPrice()});
        }
    }

    // Listeners for buttons
    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = nameField.getText();
            String desc = descField.getText();
            double price = Double.parseDouble(priceField.getText());
           
            FoodItem item = new FoodItem(name, desc, price);
            foodItems.add(item);
            model.addRow(new Object[]{name, desc, price});
        }
    }

    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                foodItems.remove(selectedRow);
                model.removeRow(selectedRow);
            }
        }
    }

    private class AddToBasketListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                FoodItem item = foodItems.get(selectedRow);
                basketItems.add(item);
                JOptionPane.showMessageDialog(null, "Added to Basket: " + item.getName());
            }
        }
    }

    private class ViewBasketListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            BasketFrame basketFrame = new BasketFrame(basketItems);
            basketFrame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HospitalRestaurantManagementSystem frame = new HospitalRestaurantManagementSystem();
            frame.setVisible(true);
        });
    }
}
