package restaurantpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class BasketFrame extends JFrame {
    private JList<String> basketList;
    private DefaultListModel<String> listModel;
    private List<FoodItem> basketItems;
    private double totalAmount;

    public BasketFrame(List<FoodItem> basketItems) {
        this.basketItems = basketItems;

        // Frame settings
        setTitle("Basket");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout settings
        setLayout(new BorderLayout());

        // List settings
        listModel = new DefaultListModel<>();
        basketList = new JList<>(listModel);
        loadBasketData();
        add(new JScrollPane(basketList), BorderLayout.CENTER);

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        JButton removeButton = new JButton("Remove Item");
        removeButton.addActionListener(new RemoveButtonListener());
        buttonPanel.add(removeButton);

        JButton generateInvoiceButton = new JButton("Generate Invoice");
        generateInvoiceButton.addActionListener(new GenerateInvoiceListener());
        buttonPanel.add(generateInvoiceButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadBasketData() {
        listModel.clear();
        totalAmount = 0;
        for (FoodItem item : basketItems) {
            listModel.addElement(item.getName() + " - $" + item.getPrice());
            totalAmount += item.getPrice();
        }
        listModel.addElement("Total: $" + totalAmount);
    }

    // Listener for the Remove Item button
    private class RemoveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = basketList.getSelectedIndex();
            if (selectedIndex >= 0 && selectedIndex < basketItems.size()) {
                basketItems.remove(selectedIndex);
                loadBasketData();
            }
        }
    }

    // Listener for the Generate Invoice button
    private class GenerateInvoiceListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, "Generating Invoice...\nTotal Amount: $" + totalAmount);
        }
    }
}
